package xyz.lsmg.findanswer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import xyz.lsmg.findanswer.find.Clear;
import xyz.lsmg.findanswer.find.startInquire;

import javax.servlet.http.HttpSession;

/**
 * @ClassName index
 * @Description TODO
 * Author lsmg
 * Date 2019/4/19 18:13
 * @Version 1.0
 **/
@Controller
public class IndexController {
    @PostMapping("/inquire")
    public String find(HttpSession session, @RequestParam("quesion")String quesionText){
        session.setAttribute("answer","");
        String[] line = quesionText.split("\\r?\\n");
        startInquire startInquire = null;
        try {
            startInquire=new startInquire(line);
        }catch (Exception e){e.printStackTrace();
        }
        String answer = startInquire.getAnswer();
        session.setAttribute("answer",answer);

        Clear clear = new Clear(session);
        clear.start();

        return "redirect:/";
    }

}
