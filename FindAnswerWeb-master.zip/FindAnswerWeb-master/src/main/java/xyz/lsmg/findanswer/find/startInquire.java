package xyz.lsmg.findanswer.find;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName startInquire
 * @Description TODO
 * Author lsmg
 * Date 2019/4/17 16:46
 * @Version 1.0
 **/
public class startInquire {
    private String answer;

    public String getAnswer() {
        return answer;
    }

    public startInquire(String[] quesText) throws Exception{
        answer="";
        ReadAnswer readAnswer = new ReadAnswer();
        ReadQuesion readQuesion = new ReadQuesion(quesText);

        List<Quesion> quesionList =new ArrayList<Quesion>();
        List<Quesion> webQuesionList = new ArrayList<Quesion>();

        quesionList = readAnswer.getQuesionList();
        webQuesionList = readQuesion.getOriginQuesions();

        StringBuffer stringBuffer = new StringBuffer();
        int quesionTotal=0;

        int quesionAmount = 1;
        for(Quesion webQuesion : webQuesionList){

            float maxSimple = 0;
            float templeSimple = 0;

            String answer = "";
            Quesion answerQuesion=null;

            String answerLongText="";

            for(Quesion quesion : quesionList){

                String webText = webQuesion.getQuesionText();
                webText = deleteTexts(webText);

                String Text = quesion.getQuesionText();

                templeSimple = LevenshteinDistance.getSimilarityRatio(webText,Text);


                if(templeSimple > maxSimple){
                    maxSimple = templeSimple;
                    answerQuesion = quesion;


                }
            }
            if(answerQuesion.getAnswerText().equals("")){
                answerLongText = answerQuesion.getQuesionText();
                answerLongText = deleteQuesionText(answerQuesion.getQuesionText(),webQuesion.getQuesionText());
                answer = "第"+quesionAmount+"题目题库相似度: "+maxSimple+"答案文本: "+answerLongText+"\r\n";
            }else {
                answerLongText = answerQuesion.getTrueAnswerText();
                answer = "第"+quesionAmount+"题目的选项为-->"+answerQuesion.getAnswerText()+"答案文本: "+answerLongText+"\r\n";
            }

            if(maxSimple>0.3){
                stringBuffer.append(answer);
                quesionTotal++;
            }else{
                stringBuffer.append("第"+quesionAmount+"题没有答案 等待题库更新\r\n");
            }
            //}
            quesionAmount++;
        }
        stringBuffer.append("一共查询到: "+quesionTotal+"\r\n");
        stringBuffer.append("预计分数为: "+quesionTotal*2);
        answer=stringBuffer.toString();
    }


    public static String deleteTexts(String line){
        String []deleteText = {"哪","几项","指的是","下列哪一项为正确选项","正确","【单选】","【多选】","、","《","》","_","所"};
        for(String string : deleteText){
            line=line.replace(string,"");
        }
        return line;
    }


    public static String deleteQuesionText(String longAnswer, String quesionText){
        quesionText=deleteTexts(quesionText);
        for(int i=0;i<=quesionText.length()-1;i++){
            if(longAnswer.contains(quesionText.charAt(i)+"")&&quesionText.charAt(i)>59){
                longAnswer = longAnswer.replace(quesionText.charAt(i)+"","");
            }
        }
        return longAnswer;
    }
}
