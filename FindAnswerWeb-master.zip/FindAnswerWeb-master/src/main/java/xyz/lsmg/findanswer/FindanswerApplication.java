package xyz.lsmg.findanswer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindanswerApplication {

    public static void main(String[] args) {
        SpringApplication.run(FindanswerApplication.class, args);
    }

}
