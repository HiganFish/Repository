package xyz.lsmg.findanswer.find;

import javax.servlet.http.HttpSession;

/**
 * @ClassName Clear
 * @Description TODO
 * Author lsmg
 * Date 2019/4/19 19:41
 * @Version 1.0
 **/
public class Clear extends Thread{
    HttpSession session;
    public Clear(HttpSession session){
        this.session = session;
    }
    @Override
    public void run(){
        try{
            System.out.println("clear");
            Thread.sleep(1000);
            session.invalidate();
        }catch (Exception e){e.printStackTrace();

        }
    }
}
