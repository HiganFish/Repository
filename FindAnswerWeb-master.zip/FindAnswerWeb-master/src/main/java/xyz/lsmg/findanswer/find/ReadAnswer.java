package xyz.lsmg.findanswer.find;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ReadAnswer
 * @Description TODO
 * Author lsmg
 * Date 2019/4/17 16:37
 * @Version 1.0
 **/
public class ReadAnswer {

    //题库路径
    String[] QuesionBank;
    Quesion quesion;
    List<Quesion> quesionList;

    ReadAnswer() throws Exception{
        quesion = new Quesion();
        quesionList=new ArrayList<Quesion>();

        String[] dirName = new String[]{"校史"};

        String parentPath = System.getProperty("user.dir")+File.separator+dirName[0]+File.separator;
        System.out.println(parentPath);
        QuesionBank = new String[]{parentPath+"单项选择题库.txt",parentPath+"单项选择题库补充.txt",parentPath+"多项选择题库.txt",parentPath+"长知识点.txt"};//,parentPath+"短知识点.txt"

        readStringFromBank();
    }

    /**
     * @Author lsmg
     * @Description //TODO
     * 用于从题库读取字符串 传入处理函数处理字符串
     * @Date 16:52 2019/4/17
     * @return void
     **/
    public void readStringFromBank() throws Exception{

        for(String path :QuesionBank){
            FileInputStream fileInputStream = new FileInputStream(new File(path));
            InputStreamReader in = new InputStreamReader(fileInputStream,"GB2312");
            BufferedReader bf = new BufferedReader(in);

            String line="";
            while((line = bf.readLine())!=null){
                processString(line);
            }
        }
    }

    public void processString(String pendingProcessString){

        //判断字符串第一个是否为数字 为数字且包含.则为题干 生成一个题目对象
        if(pendingProcessString.charAt(0)<57 &&pendingProcessString.contains(".")){

            if(quesion != null){
                quesionList.add(quesion);
                quesion = null;
            }
            quesion = new Quesion();

            //生成新对象后加入到对象题干中
            quesion.setQuesionText(pendingProcessString);
            addQuesionAnswer(pendingProcessString);
            return;
        }
        addQuesionAnswer(pendingProcessString);
        //判断是否为选项是则 加入选项
        if(pendingProcessString.charAt(0)>='A' && pendingProcessString.charAt(0)<='E'){
            addQuesionAnswerText(pendingProcessString);
        }

        //都不符合则为剩余题干
        quesion.setQuesionText(quesion.getQuesionText()+pendingProcessString);
    }

    public void addQuesionAnswerText(String answerText){
        quesion.setChoiceText(answerText, answerText.charAt(0));
    }

    public void addQuesionAnswer(String line){
        for(int i = line.indexOf("（")+1;i <= line.indexOf("）")-1;i++){
            quesion.setAnswerText(quesion.getAnswerText()+line.charAt(i));
        }
    }

    public List<Quesion> getQuesionList() {
        return quesionList;
    }
}
