package xyz.lsmg.findanswer.find;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ReadQuesion
 * @Description TODO
 * Author lsmg
 * Date 2019/4/16 18:55
 * @Version 1.0
 **/
public class ReadQuesion {
    private List<Quesion> originQuesions;
    private Quesion originQuesion;
    private String[] quesion;

    ReadQuesion(String[] quesion){
        originQuesions = new ArrayList<Quesion>();

        boolean quesionStart=false;

        this.quesion = quesion;
        for(int i=0;i<=quesion.length-1;i+=(quesionStart?5:1)){
            String line = quesion[i];
            //除去开头多余行数
            if(!quesionStart){
                if(!line.contains("1【单选】")){
                    continue;
                }else{
                    quesionStart=true;
                }
            }

            if(line.contains("E. E")){
                if(quesion[i+1].contains("F. F")){
                    i++;
                }
                i++;
            }
            if(i>=40){
                for(int j=0;j<=4;j++){
                    if(quesion[i+j].contains("立即交卷")){
                        return;
                    }
                }
            }
            String []result=new String[5];
            result[0]=quesion[i];
            result[1]=quesion[i+1];
            result[2]=quesion[i+2];
            result[3]=quesion[i+3];
            result[4]=quesion[i+4];
            stringProcess(result);
        }
    }

    public List<Quesion> getOriginQuesions() {
        return originQuesions;
    }

    void stringProcess(String[] string){
        originQuesion = new Quesion();

        originQuesion.setQuesionText(string[0]);

        for(int i=1;i<=string.length-1;i++){
            originQuesion.setChoiceText(string[i],i);
        }

        originQuesions.add(originQuesion);


        originQuesion=null;
    }
    
}
