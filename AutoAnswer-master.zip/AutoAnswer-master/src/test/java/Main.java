import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName Main
 * @Description TODO
 * Author lsmg
 * Date 2019/4/16 19:12
 * @Version 1.0
 **/
public class Main {
    public static void main(String[] args) throws Exception{
        List<Quesion> quesions =new ArrayList<Quesion>();
        List<Quesion> originQuesions = new ArrayList<Quesion>();
        int quesionMember=1;
        int quesionTotal=0;

        StringBuffer stringBuffer = new StringBuffer();

        ReadAnswer readAnswer = new ReadAnswer();
        quesions = readAnswer.getQuesions();

        ReadQuesion readQuesion = new ReadQuesion();
        originQuesions = readQuesion.getOriginQuesions();

        for(Quesion quesion : originQuesions){
            float maxCommon = 0;
            float maxCommonTem = 0;
            String answer="";
            for(Quesion tquesion : quesions){
                maxCommonTem=LevenshteinDistance.getSimilarityRatio(quesion.getQuesionText(),tquesion.getQuesionText());

                if(maxCommonTem>maxCommon){
                    maxCommon = maxCommonTem;
                    answer=tquesion.getAnswerText();
                    if(answer==""){
                        answer=tquesion.getQuesionText();
                    }
                }
            }
            String cout="";
            if(maxCommon>0.5){
                cout="第"+quesionMember+"题答案为: "+answer;
                quesionTotal++;
            }else{
                cout="第"+quesionMember+"题暂时无答案待题库更新";
            }
            quesionMember++;
            stringBuffer.append(cout+"\r\n");
        }
        stringBuffer.append("一共查询到: "+quesionTotal);
        coutAnswer(stringBuffer);
    }
    public static void coutAnswer(StringBuffer stringBuffer) throws  Exception{
        File file = new File("C:\\Users\\rjd67\\Desktop\\题目答案.txt");
        file.createNewFile();

        FileOutputStream fileOutputStream = new FileOutputStream(file);
        OutputStreamWriter out = new OutputStreamWriter(fileOutputStream,"GB2312");
        BufferedWriter bf = new BufferedWriter(out);
        bf.write(stringBuffer.toString());
        bf.close();
    }
}
