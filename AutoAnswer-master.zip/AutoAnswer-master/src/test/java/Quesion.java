/**
 * @ClassName Quesion
 * @Description TODO
 * Author lsmg
 * Date 2019/4/16 17:47
 * @Version 1.0
 **/
public class Quesion {
    private String QuesionText;
    private String[] ChoiceText;
    private String AnswerText;
    Quesion(){
        QuesionText="";
        ChoiceText = new String[4];
        AnswerText ="";
    }

    public String getQuesionText() {
        return QuesionText;
    }

    public void setQuesionText(String quesionText) {
        QuesionText = quesionText;
    }

    public String[] getChoiceText() {
        return ChoiceText;
    }

    public void setChoiceText(String choiceText,char choice) {
        ChoiceText[choice-65] = choiceText;
    }

    public String getAnswerText() {
        return AnswerText;
    }

    public void setAnswerText(String answerText) {
        AnswerText = answerText;
    }
}
