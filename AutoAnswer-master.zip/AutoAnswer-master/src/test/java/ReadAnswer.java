import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ReadAnswer
 * @Description TODO
 * Author lsmg
 * Date 2019/4/16 17:45
 * @Version 1.0
 **/
public class ReadAnswer {

    private List<Quesion> quesions;
    private Quesion quesion;

    ReadAnswer() throws Exception{
        quesions = new ArrayList<Quesion>();
        //单选题
        readSingle();
        //单选知识点
        readSinglePoint();
        //多选题
        readDouble();
        //大量知识点
        readPoints();

    }
    private void readPoints() throws  Exception{
        File file_single = new File("C:\\Users\\rjd67\\Desktop\\多项选择知识点.txt");

        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file_single),"GB2312");
        BufferedReader bf = new BufferedReader(inputStreamReader);

        String line="";
        while ((line=bf.readLine())!=null){
            stringPointProcess(line);
        }
        bf.close();
    }
    private void readSingle() throws Exception{
        File file_single = new File("C:\\Users\\rjd67\\Desktop\\单项选择题库.txt");

        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file_single),"GB2312");
        BufferedReader bf = new BufferedReader(inputStreamReader);

        String line="";
        while ((line=bf.readLine())!=null){
            stringProcess(line);
        }
        bf.close();
    }
    private void readSinglePoint()throws Exception{
        File file_singlePoint = new File("C:\\Users\\rjd67\\Desktop\\单项选择知识点.txt");
        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file_singlePoint),"GB2312");
        BufferedReader bf = new BufferedReader(inputStreamReader);

        String line="";
        while ((line=bf.readLine())!=null){
            stringProcessPoint(line);
        }
    }
    private void readDouble() throws Exception{
        File file_Double = new File("C:\\Users\\rjd67\\Desktop\\多项选择题库.txt");

        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file_Double),"GB2312");
        BufferedReader bf = new BufferedReader(inputStreamReader);

        String line="";
        while ((line=bf.readLine())!=null){
            stringProcesses(line);
        }
        bf.close();
    }

    public List<Quesion> getQuesions() {
        return quesions;
    }

    void stringPointProcess(String string){
        System.out.println(string);
        if(string.length()<=4){
            quesion.setQuesionText(quesion.getQuesionText()+string);
            return;
        }
        if(string.charAt(2)=='.'||string.charAt(3)=='.'||string.charAt(1)=='.'){
            if(quesion !=null){
                quesions.add(quesion);
                quesion =null;
            }
            quesion = new Quesion();
        }
        quesion.setQuesionText(quesion.getQuesionText()+string);
    }
    void stringProcesses(String string){
        //判断题干
        System.out.println(string);
        if(string.length()>2&&string.charAt(2)=='.'){
            if(quesion !=null){
                quesion =null;
            }
            quesion = new Quesion();
        }
        if(string.charAt(0)!='A' && string.charAt(0)!='B' &&string.charAt(0)!='C'&&string.charAt(0)!='D'){
            quesionAddAnswers(string);
            quesion.setQuesionText(quesion.getQuesionText()+string);
            return;
        }
        switch (string.charAt(0)){
            case 'A': quesion.setChoiceText(string,'A');
                break;
            case 'B': quesion.setChoiceText(string,'B');
                break;
            case 'C': quesion.setChoiceText(string,'C');
                break;
            case 'D': quesion.setChoiceText(string,'D');
                quesions.add(quesion);
                break;
            case 'E': quesion.setChoiceText(string,'E');
                quesions.add(quesion);
                break;
        }
    }
    void stringProcessPoint(String string){
        quesion = new Quesion();
        quesion.setQuesionText(string);
        quesions.add(quesion);
        quesion = null;
    }

    void stringProcess(String string){
        //判断题干
        System.out.println(string);
        if(string.length()>2&&string.charAt(2)=='.'){
            quesion = new Quesion();
        }
        if(string.charAt(0)!='A' && string.charAt(0)!='B' &&string.charAt(0)!='C'&&string.charAt(0)!='D'){
            quesionAddAnswer(string);
            quesion.setQuesionText(quesion.getQuesionText()+string);
            return;
        }
        switch (string.charAt(0)){
            case 'A': quesion.setChoiceText(string,'A');
                break;
            case 'B': quesion.setChoiceText(string,'B');
                break;
            case 'C': quesion.setChoiceText(string,'C');
                break;
            case 'D': quesion.setChoiceText(string,'D');
                quesions.add(quesion);
                quesion=null;
                break;
        }

    }
    void quesionAddAnswers(String line){
        if(line.contains("（")&&line.contains("）")){
            for(int i=line.indexOf("（")+1;i<=line.indexOf("）")-1;i++){
                quesion.setAnswerText(quesion.getAnswerText()+line.charAt(i));
            }
        }
    }
    void quesionAddAnswer(String line){
        if(line.contains("（A）")){
            quesion.setAnswerText("A");
        }
        if(line.contains("（B）")){
            quesion.setAnswerText("B");
        }
        if(line.contains("（C）")){
            quesion.setAnswerText("C");
        }
        if(line.contains("（D）")){
            quesion.setAnswerText("D");
        }
    }
    void quesionCoutTest() throws Exception{
        File file = new File("C:\\Users\\rjd67\\Desktop\\st000.txt");
        file.createNewFile();

        FileOutputStream fileOutputStream = new FileOutputStream(file);
        OutputStreamWriter out = new OutputStreamWriter(fileOutputStream,"GB2312");
        BufferedWriter bf = new BufferedWriter(out);

        for (Quesion quesion1 :quesions){
            bf.write(quesion1.getQuesionText()+"\r\n");
            bf.flush();
            bf.write(quesion1.getChoiceText()[0]+" "+quesion1.getChoiceText()[1]+" "+quesion1.getChoiceText()[2]+" "+quesion1.getChoiceText()[3]+"\r\n");
            bf.flush();
            bf.write("----answer-----"+quesion1.getAnswerText()+"\r\n");
            bf.flush();
        }
        bf.close();
    }
}
