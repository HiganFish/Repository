import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ReadQuesion
 * @Description TODO
 * Author lsmg
 * Date 2019/4/16 18:55
 * @Version 1.0
 **/
public class ReadQuesion {
    private List<Quesion> originQuesions;
    private Quesion originQuesion;

    ReadQuesion()throws Exception{
        originQuesions = new ArrayList<Quesion>();

        File file_single = new File("C:\\Users\\rjd67\\Desktop\\net.txt");

        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file_single),"GB2312");
        BufferedReader bf = new BufferedReader(inputStreamReader);

        String line="";
        String []result=new String[5];
        while ((line=bf.readLine())!=null){
            result[0]=line;
            result[1]=bf.readLine();
            result[2]=bf.readLine();
            result[3]=bf.readLine();
            result[4]=bf.readLine();
            stringProcess(result);
        }
    }

    public List<Quesion> getOriginQuesions() {
        return originQuesions;
    }

    void stringProcess(String[] string){
        originQuesion = new Quesion();

        originQuesion.setQuesionText(string[0]);
        originQuesions.add(originQuesion);

        System.out.println(originQuesion.getQuesionText());

        originQuesion=null;
    }
}
