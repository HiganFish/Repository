import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName Main
 * @Description TODO
 * Author lsmg
 * Date 2019/4/17 16:46
 * @Version 1.0
 **/
public class Main {
    public static void main(String[] args) throws Exception{
        ReadAnswer readAnswer = new ReadAnswer();
        ReadQuesion readQuesion = new ReadQuesion();

        List<Quesion> quesionList =new ArrayList<Quesion>();
        List<Quesion> webQuesionList = new ArrayList<Quesion>();

        quesionList = readAnswer.getQuesionList();
        webQuesionList = readQuesion.getOriginQuesions();

        StringBuffer stringBuffer = new StringBuffer();
        int quesionTotal=0;

        int quesionAmount = 1;
        for(Quesion webQuesion : webQuesionList){

            float maxSimple = 0;
            float templeSimple = 0;

            String answer = "";
            Quesion answerQuesion=null;

            String answerLongText="";

//            String forceAnswer = "";

            for(Quesion quesion : quesionList){

                String webText = webQuesion.getQuesionText();
                webText = deleteTexts(webText);

                String Text = quesion.getQuesionText();

                templeSimple = LevenshteinDistance.getSimilarityRatio(webText,Text);

//                //tempForceSimple = forceCompe(webText, Text);
//                tempForceSimple = forceCompeChoice(quesion.getQuesionText(), webQuesion);
//
//                if(tempForceSimple > maxForceSimple){
//                    maxForceSimple = tempForceSimple;
//                    forceAnswer =  "强制第"+quesionAmount+"题目的答案为-->"+quesion.getAnswerText()+"题库相似度: "+maxForceSimple+"答案文本: "+quesion.getTrueAnswerText()+"\r\n";
//                }

                if(templeSimple > maxSimple){
                    maxSimple = templeSimple;
                    answerQuesion = quesion;


                }
            }
            if(answerQuesion.getAnswerText().equals("")){
                answerLongText = answerQuesion.getQuesionText();
                answerLongText = deleteQuesionText(answerQuesion.getQuesionText(),webQuesion.getQuesionText());
                answer = "第"+quesionAmount+"题目题库相似度: "+maxSimple+"答案文本: "+answerLongText+"\r\n";
            }else {
                answerLongText = answerQuesion.getTrueAnswerText();
                answer = "第"+quesionAmount+"题目的选项为-->"+answerQuesion.getAnswerText()+"答案文本: "+answerLongText+"\r\n";
            }


//            if(maxForceSimple>maxSimple && maxForceSimple>0.4 && maxForceSimple<0.8 && maxSimple<0.3){
//                stringBuffer.append(forceAnswer);
//                quesionTotal++;
//            }else{
                if(maxSimple>0.3){
                    stringBuffer.append(answer);
                    quesionTotal++;
                }else{
                    stringBuffer.append("第"+quesionAmount+"题没有答案 等待题库更新\r\n");
                }
            //}
            quesionAmount++;
        }
        stringBuffer.append("一共查询到: "+quesionTotal+"\r\n");
        stringBuffer.append("预计分数为: "+quesionTotal*2);

        coutAnswer(stringBuffer);
    }

    public static String deleteTexts(String line){
        String []deleteText = {"哪","几项","指的是","下列哪一项为正确选项","正确","【单选】","【多选】","、","《","》","_","所"};
        for(String string : deleteText){
            line=line.replace(string,"");
        }
        return line;
    }

    public static void coutAnswer(StringBuffer stringBuffer) throws  Exception{
        File file = new File("C:\\Users\\rjd67\\Desktop\\题目答案.txt");
        file.createNewFile();

        FileOutputStream fileOutputStream = new FileOutputStream(file);
        OutputStreamWriter out = new OutputStreamWriter(fileOutputStream,"GB2312");
        BufferedWriter bf = new BufferedWriter(out);
        bf.write(stringBuffer.toString());
        bf.close();
    }

    public static String deleteQuesionText(String longAnswer, String quesionText){
        quesionText=deleteTexts(quesionText);
        for(int i=0;i<=quesionText.length()-1;i++){
            if(longAnswer.contains(quesionText.charAt(i)+"")&&quesionText.charAt(i)>59){
                longAnswer = longAnswer.replace(quesionText.charAt(i)+"","");
            }
        }
        System.out.println(longAnswer);
        return longAnswer;
    }

//    public static float forceCompe(String string, String ques){
//        int length = string.length();
//        String[] strings = new String[3];
//        strings[0] = string.substring(0,length/3);
//        strings[1] = string.substring(length/3,length/3*2);
//        strings[2] = string.substring(length/3*2,length-1);
//
//        float common = 0;
//        float commonTemt = 0;
//
//        for(int i=0;i<=2;i++){
//            commonTemt = LevenshteinDistance.getSimilarityRatio(strings[i],ques);
//            if(commonTemt > common){
//                common = commonTemt;
//            }
//        }
//        return common;
//    }

//    public static float forceCompeChoice(String string, Quesion ques){
//        int length = string.length();
//        if(length <=3){
//            return 0;
//        }
////        String[] strings = new String[3];
////        strings[0] = string.substring(0,length/3);
////        strings[1] = string.substring(length/3,length/3*2);
////        strings[2] = string.substring(length/3*2,length-1);
//
//        float common = 0;
//        double[] commonTemt={0,0,0,0,0};
//        int answerIndex=0;
//
//        for(String answerText : ques.getChoiceText()){
//            if(answerText == null){
//                break;
//            }
//
//            System.out.println("-----------------");
//            System.out.println(string);
//            System.out.println(answerText);
//
//            commonTemt[answerIndex] = LevenshteinDistance.getSimilarityRatio(answerText,string);
//            answerIndex++;
//        }
//        int i=0;
//        while (commonTemt[i] !=0){
//            common+=commonTemt[i];
//            i++;
//        }
//        return common;
//    }
}
