/**
 * @ClassName Demo
 * @Description TODO
 * Author lsmg
 * Date 2019/4/18 18:41
 * @Version 1.0
 **/
public class Demo {
    public static void main(String[] args) {
        double[] a ={0.1,0.1,0.14};
        System.out.println(a.length);
    }
}
