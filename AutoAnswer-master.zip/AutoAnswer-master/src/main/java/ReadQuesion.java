import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ReadQuesion
 * @Description TODO
 * Author lsmg
 * Date 2019/4/16 18:55
 * @Version 1.0
 **/
public class ReadQuesion {
    private List<Quesion> originQuesions;
    private Quesion originQuesion;

    ReadQuesion()throws Exception{
        originQuesions = new ArrayList<Quesion>();

        File file_single = new File("C:\\Users\\rjd67\\Desktop\\net.txt");

        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file_single),"GB2312");
        BufferedReader bf = new BufferedReader(inputStreamReader);

        //除去开头多余行数
//        while(!bf.readLine().contains("限时")){}

        String line="";
        String []result=new String[5];
        while ((line=bf.readLine())!=null){
            if(line.equals("立即交卷")){
                return;
            }
            result[0]=line;
            result[1]=bf.readLine();
            result[2]=bf.readLine();
            result[3]=bf.readLine();
            result[4]=bf.readLine();
            stringProcess(result);
        }
    }

    public List<Quesion> getOriginQuesions() {
        return originQuesions;
    }

    void stringProcess(String[] string){
        originQuesion = new Quesion();

        originQuesion.setQuesionText(string[0]);

        for(int i=1;i<=string.length-1;i++){
            originQuesion.setChoiceText(string[i],i);
        }

        originQuesions.add(originQuesion);


        originQuesion=null;
    }
}
