import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * @ClassName UI
 * @Description UI界面
 * Author lsmg
 * Date 2019/3/28 20:52
 * @Version 1.0
 **/
public class UI {
    private JFrame mainJf;
    private JTextArea jTextArea_Group; //显示组别
    private JButton jB_yd;//移动
    private JButton jB_sp;//视频
    private JButton jB_hd;//后端
    private JButton jB_qd;//前端
    private JButton jB_yx;//运营
    private JButton jB_yb;//易班
    private JButton jB_sj;//视觉
    private JButton jB_bg;//办公
    private JButton jB_Start;
    private JButton jB_Save;
    private int totalGroupId=0;
    private Color buttonDefaultColor;

//    private static final int

    ArrayList<ArrayList<Member>> Members_list;
    FileCurd fileCurd;

    JButton[][] jB=new JButton[6][6];
    JTextArea [][] jT=new JTextArea[2][6];

    String leaveReason;

    JOptionPane jOptionPane=new JOptionPane();

    static private String[] groupIdToName={"前端组","视觉组","后端组","移动组","易班组","办公组","运营组","视频组"};

    public static void main(String[] args) throws Exception{
        UI ui=new UI();
    }
    public UI(){
        leaveReason="";
        new Index();
    }
    class Index extends JFrame implements ActionListener {
        Index(){
            mainJf=new JFrame();
            mainJf.setBounds(0,0,1000,460);
            mainJf.setVisible(true);
            mainJf.setResizable(false);
            mainJf.setLayout(null);


            jB_Start=new JButton("今日签到");
            jB_Start.setBounds(20,10,100,40);
            jB_Start.addActionListener(this);
            jB_Start.setFont(new Font("微软雅黑",Font.PLAIN,15));

            jB_Save=new JButton("保存签到");
            jB_Save.setBounds(130,10,100,40);
            jB_Save.addActionListener(this);
            jB_Save.setFont(new Font("微软雅黑",Font.PLAIN,15));

            jB_yd=new JButton("前端");
            jB_yd.setBounds(20,60,100,80);
            jB_yd.addActionListener(this);
            jB_yd.setFont(new Font("微软雅黑",Font.PLAIN,25));

            jB_sp=new JButton("视觉");
            jB_sp.setBounds(20,150,100,80);
            jB_sp.addActionListener(this);
            jB_sp.setFont(new Font("微软雅黑",Font.PLAIN,25));

            jB_hd=new JButton("后端");
            jB_hd.setBounds(20,240,100,80);
            jB_hd.addActionListener(this);
            jB_hd.setFont(new Font("微软雅黑",Font.PLAIN,25));

            jB_qd=new JButton("移动");
            jB_qd.setBounds(20,330,100,80);
            jB_qd.addActionListener(this);
            jB_qd.setFont(new Font("微软雅黑",Font.PLAIN,25));

            jB_yx=new JButton("易班");
            jB_yx.setBounds(130,60,100,80);
            jB_yx.addActionListener(this);
            jB_yx.setFont(new Font("微软雅黑",Font.PLAIN,25));
            
            jB_yb=new JButton("办公");
            jB_yb.setBounds(130,150,100,80);
            jB_yb.addActionListener(this);
            jB_yb.setFont(new Font("微软雅黑",Font.PLAIN,25));
            
            jB_sj=new JButton("运营");
            jB_sj.setBounds(130,240,100,80);
            jB_sj.addActionListener(this);
            jB_sj.setFont(new Font("微软雅黑",Font.PLAIN,25));
            
            jB_bg=new JButton("视频");
            jB_bg.setBounds(130,330,100,80);
            jB_bg.addActionListener(this);
            jB_bg.setFont(new Font("微软雅黑",Font.PLAIN,25));
            
            jTextArea_Group=new JTextArea();
            jTextArea_Group.setBounds(550,5,75,35);
            jTextArea_Group.setText("移动组");
            jTextArea_Group.setFont(new Font("微软雅黑",Font.BOLD,25));

            //默认按钮背景颜色
            buttonDefaultColor=jB_bg.getBackground();

            for(int i=1;i<=12;i++){
                setButton(i);
            }
            for(int j=0;j<=11;j++){
                int x1=j/2; //x1 竖直方向
                int x2=j%2; //x2 水平第一个方向
                if(x2==0){
                    x2--;
                }else{
                    x2=2;
                }
                for(int i=0;i<=2;i++){
                    x2+=1;
//                    System.out.println("x1: "+x1);
//                    System.out.println("x2: "+x2);
                    jB[x1][x2].addActionListener(this);
                }
            }

            mainJf.add(jB_Start);
            mainJf.add(jB_Save);
            mainJf.add(jB_yd);
            mainJf.add(jB_sp);
            mainJf.add(jB_hd);
            mainJf.add(jB_qd);
            mainJf.add(jB_yx);
            mainJf.add(jB_yb);
            mainJf.add(jB_sj);
            mainJf.add(jB_bg);
            mainJf.add(jTextArea_Group);
            mainJf.repaint();
            mainJf.setLocationRelativeTo(null); //作用为居中 原因未知
            mainJf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton jButton=(JButton)e.getSource();

            //保存按钮
            if(jButton==jB_Save){
                fileCurd.setMembers_list_out(Members_list);
                try{
                    fileCurd.memberSave();
                    jOptionPane.showMessageDialog(null,"保存成功");

                }catch (Exception j){
                    j.printStackTrace();
                }

                return;
            }

            int x=jButton.getX();
            int y=jButton.getY();
            if(x>=370){
                updateRightArea(jButton);
            }
            if(x==150&&y==10){
                totalGroupId=0;
            }else{
                if(x==20){
                    totalGroupId=y/100;
                }else if(x==130){
                    totalGroupId=y/100+4;
                }

            }
            System.out.println(totalGroupId);
            //检测为开始按钮后 对应的生成本日的输出txt文档
            if(jButton==jB_Start){
                //生成本日的输出txt文档
                Date date=new Date();
                SimpleDateFormat sdFormat=new SimpleDateFormat("yyyy年MM月dd日hh时ss分钟");
                String time=sdFormat.format(date);
                mainJf.setTitle(time+"签到信息");
                try{
                    fileCurd=new FileCurd(time);
                    //获取成员列表
                    Members_list=fileCurd.getMembers_list();
                }catch (Exception error){
                    error.printStackTrace();
                    jOptionPane.showMessageDialog(null,"读取人员信息失败");
                }
            }
            updateUi();
        }
    }
    class Reason extends JFrame implements ActionListener{
        JButton jB_SaveReason;
        JTextField jTextField;
        JFrame mainJFrame01;
        Member member001;
        Reason(Member member001){
            this.member001=member001;
            mainJFrame01=new JFrame();
            mainJFrame01.setUndecorated(true);
            mainJFrame01.setBounds(MouseInfo.getPointerInfo().getLocation().x,MouseInfo.getPointerInfo().getLocation().y,150,60);
            mainJFrame01.setVisible(true);
            mainJFrame01.setLayout(null);
            mainJFrame01.setResizable(false);

            jTextField=new JTextField();
            jTextField.setBounds(0,0,150,30);

            jB_SaveReason=new JButton("保存");
            jB_SaveReason.setBounds(0,30,150,30);
            jB_SaveReason.addActionListener(this);
            mainJFrame01.add(jTextField);
            mainJFrame01.add(jB_SaveReason);

        }
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton jButton=(JButton)e.getSource();
            if(jButton==jB_SaveReason){
                member001.setReason(jTextField.getText());
                jOptionPane.showMessageDialog(null,"保存成功");
                mainJFrame01.dispose();//关闭窗口
            }
        }
    }
    void updateUi(){
        //每次点击左边组别按钮后 对应的更改文本框的名字为对应组别的名字
        setTextText(totalGroupId);
        updateButtonAmount();//更新按钮数目
        updateTextAmount();//更新标签数目
        //更改标题为组别
        changeTitle();
    }
    void updateRightArea(JButton jButton){
        String personIdXY=getJTButton(jButton);
        int personId=(personIdXY.charAt(0)-48)*2+((personIdXY.charAt(1)-48)<=2?0:1);
        AddButtonStatus(totalGroupId,personId,(personIdXY.charAt(1)-48)%3+1);
        updateButtonStatus();//更新按钮状态
    }
    /**
     * @Author lsmg
     * @Description //用于每次切换组别文本框的文字变化 姓名=，= 
     * @Date 21:07 2019/3/29
     * @param groupId 组别
     * @return void
     **/
    void setTextText(int groupId){
        for(int i=0;i<=Members_list.get(groupId).size()-1;i++){
            int x1=i/2;
            int x2=i%2;

            String name=Members_list.get(groupId).get(i).getName();
            jT[x2][x1].setText(name);
        }
        updateButtonStatus();
    }
    /**
     * @Author lsmg
     * @Description //修改对应人员的 status
     * @Date 12:58 2019/3/30
     * @param groupId 人物的组别
     * @param personId 人物的个人信息
     * @param statusId 人物要修改为的状态
     * @return void
     **/
    void AddButtonStatus(int groupId,int personId,int statusId){
        Member member=Members_list.get(groupId).get(personId);
        member.setStatus(statusId);
        if(statusId==2){
            new Reason(member);
        }
    }
    void updateButtonAmount(){
        int maxSize=Members_list.get(totalGroupId).size();
        for(int i=0;i<=11;i++){
            int y=i/2;
            int x=(i%2==0?0:3);
            for(int j=0;j<=2;j++){
                jB[y][x+j].setVisible(true);
            }
        }
        for(int i=maxSize;i<=11;i++){
            int y=i/2;
            int x=(i%2==0?0:3);
            for(int j=0;j<=2;j++){
                jB[y][x+j].setVisible(false);
            }
        }
    }
    void updateTextAmount(){
        int maxSize=Members_list.get(totalGroupId).size();
        for(int i=0;i<=11;i++){
            int y=i/2;
            int x=(i%2==0?0:1);
            jT[x][y].setVisible(true);
        }
        for(int i=maxSize;i<=11;i++){
            int y=i/2;
            int x=(i%2==0?0:1);
            jT[x][y].setVisible(false);
        }
    }
    /**
     * @Author lsmg
     * @Description //用于每次更改后按钮状态的更新
     * @Date 13:00 2019/3/30
     * @return void
     **/
    void updateButtonStatus(){
        //x横向按钮
        //y排数
        int maxSize=Members_list.get(totalGroupId).size();
        for(int y=0;y<=5;y++){
            for(int x=0;x<=1;x++){
                if((2*y+x)>maxSize-1){
                    break;
                }
                int memberStatus=Members_list.get(totalGroupId).get(2*y+x).getStatus();
                for(int i=(x==0?0:3);i<=(x==0?2:5);i++){
                    jB[y][i].setBackground(buttonDefaultColor);
                }
                if(memberStatus==0){
                    continue;
                }
                if(memberStatus==1){
                    jB[y][(x==0?0:3)].setBackground(new Color(57,197,187));
                }else if(memberStatus==2){
                    jB[y][(x==0?1:4)].setBackground(new Color(57,197,187));
                }else if(memberStatus==3){
                    jB[y][(x==0?2:5)].setBackground(new Color(57,197,187));
                }
            }
        }
    }
    /**
     * @Author lsmg
     * @Description //生成12个text框 以及相应的36个按钮
     * @Date 21:04 2019/3/29
     * @param num 控制按钮的生成 一共12个text和36个按钮
     * @return void
     **/
    void setButton(int num){
        num--;
        //控制左侧名称部分
        int x1=num/2; //x1 竖直方向
        int x2=num%2; //x2 水平第一个方向

        jT[x2][x1]=new JTextArea("空");
        jT[x2][x1].setFont(new Font("微软雅黑",Font.PLAIN,20));
        jT[x2][x1].setBounds(num%2==0?285:615,num/2*60+52,65,30);
        mainJf.add(jT[x2][x1]);

        String button_text="";

        //控制功能按钮部分
        
        //以下x2为的是让 x2=0（左侧控制按钮）生成对应的x2 0 1 2三个按钮
        //             x2=1（右侧控制按钮）生成对应的x2 3 4 5 三个按钮
        //             x1 控制了行数 而x2控制列数
        if(x2==0){
            x2--;
        }else{
            x2=2;
        }
        for(int i=0;i<=2;i++){
            x2+=1;
            jB[x1][x2]=new JButton();
            JButton jButton=jB[x1][x2];
            //清楚按钮内边框
            jButton.setMargin(new Insets(0,0,0,0));

            jButton.setFont(new Font("微软雅黑",Font.PLAIN,15));
            jButton.setBounds(num%2==0?370+60*i:700+60*i,num/2*60+45,55,45);

            //三次一循环切换按钮名称
            switch (i){
                case 0:
                    button_text="已到";
                    break;
                case 1:
                    button_text="请假";
                    break;
                case 2:
                    button_text="未到";
                    break;
            }
            jButton.setText(button_text);
            mainJf.add(jButton);
        }
    }

    /**
     * @Author lsmg
     * @Description //找出触发检测器的按钮是右侧36的按钮其中哪一个
     * @Date 22:52 2019/3/29
     * @param jButton //监听器接收到的按钮
     * @return String 数组i和j转为String返回
     **/
    String getJTButton(JButton jButton){
        for(int i=0;i<=5;i++){
            for (int j=0;j<=5;j++){
                if(jButton==jB[i][j]){
                    return""+i+j;
                }
            }
        }
        return ""+0;
    }
    void changeTitle(){
        jTextArea_Group.setText(groupIdToName[totalGroupId]);
    }

}
