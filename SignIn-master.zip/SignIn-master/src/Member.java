/**
 * @ClassName Member
 * @Description TODO
 * Author lsmg
 * Date 2019/3/28 20:27
 * @Version 1.0
 **/
public class Member {
    private String name;
    private String group;
    private Integer status=0; //0-未处理 1-到 2-请假 3-未到

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    private String reason;

    public Member(String name, String group) {
        this.name = name;
        this.group=group;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    /**
     * @Author lsmg
     * @Description //0-未处理 1-到 2-请假 3-未到
     * @Date 22:49 2019/3/29
     * @return java.lang.Integer
     **/
    public Integer getStatus() {
        return status;
    }
    /**
     * @Author lsmg
     * @Description //TODO
     * @Date 22:49 2019/3/29
     * @param status //0-未处理 1-到 2-请假 3-未到
     * @return void
     **/
    public void setStatus(Integer status) {
        this.status = status;
    }
}
