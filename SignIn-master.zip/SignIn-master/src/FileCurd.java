import java.io.*;
import java.util.ArrayList;

/**
 * @ClassName FileCurd
 * @Description 文件的创建修改
 * Author lsmg
 * Date 2019/3/29 16:23
 * @Version 1.0
 **/
public class FileCurd {
    private String file_URL;
    //读出的人员信息
    private ArrayList<ArrayList<Member>> members_list;
    //待写出的
    private ArrayList<ArrayList<Member>> members_list_out;
    //文件名称
    private String fileName;
    static private String[] groupIdToName={"前端组","视觉组","后端组","移动组","易班组","办公组","运营组","视频组"};
    private String[] statusIdToString={"未设置","已到","请假","未到"};


    public ArrayList<ArrayList<Member>> getMembers_list() {
        return members_list;
    }
    public void setMembers_list_out(ArrayList<ArrayList<Member>> members_list_out) {
        this.members_list_out = members_list_out;
    }

    /**
     * @Author lsmg
     * @Description //创建今日的文件 以及执行导入人员信息
     * @Date 16:31 2019/3/29
     * @param file_Name 只需指定文件的日期
     * @return
     **/
    FileCurd(String file_Name)throws Exception{
        fileName=file_Name;
        members_list=new ArrayList<ArrayList<Member>>();
        memberRead();
    }
    /**
     * @Author lsmg
     * @Description //从根目录的成员txt文件读取成员信息
     * @Date 16:50 2019/3/29
     * @return void
     **/
    void memberRead()throws Exception{
        //读取文件
        File file_Member_Read=new File(System.getProperty("user.dir")+File.separator+"人员信息.txt");
        //FileReader fileReader=new FileReader(file_Member_Read);
        InputStreamReader read=new InputStreamReader(new FileInputStream(file_Member_Read),"GBK");
        BufferedReader bufferedReader=new BufferedReader(read);

        //开始进行分组加入的数据结构中
        String line="";
        String groupId="";
        int groupNum=0;
        while ((line=bufferedReader.readLine())!=null){
            if(line.charAt(2)=='@'){
                groupId=line.charAt(3)+"";
                groupNum=(line.charAt(0)-48)*10+(line.charAt(1)-48);
                //移动到数据结构中

                //暂时存储每组的成员
                ArrayList <Member>oneGroud=new ArrayList<Member>();
                for(int i=1;i<=groupNum;i++){
                    line=bufferedReader.readLine();
                    oneGroud.add(new Member(line,groupId));
                }
                members_list.add(oneGroud);
            }
        }
    }

    /**
     * @Author lsmg
     * @Description //储存人员信息
     * @Date 19:20 2019/3/30
     * @return void
     **/
    void memberSave()throws Exception{
        Excel excel=new Excel(fileName);
        ArrayList<Member> group;
        Member member;
        for(int i=0;i<=7;i++){
            group=members_list_out.get(i);
            for(int j=0;j<=group.size()-1;j++){
                excel.creatExcelRow();
                member=group.get(j);
                excel.creatExcelCell(groupIdToName[(member.getGroup().charAt(0))-48-1]);
                excel.creatExcelCell(member.getName());
                excel.creatExcelCell(statusIdToString[member.getStatus()]);
                excel.creatExcelCell(member.getReason());
            }
        }
        excel.excelSave();
        excel=null;
    }


}
