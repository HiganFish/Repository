import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;

/**
 * @ClassName Excel
 * @Description TODO
 * Author lsmg
 * Date 2019/3/30 13:49
 * @Version 1.0
 **/
public class Excel {
    private HSSFWorkbook workbook=new HSSFWorkbook();
    private HSSFSheet sheet;
    private HSSFRow row;
    private File file;

    private int excel_Row;
    private int excel_Cell;

    Excel(String date){
        file=new File(System.getProperty("user.dir")+File.separator+date+".xls");
        sheet= workbook.createSheet();
    }
    public void creatExcelRow(){
        excel_Cell=0;
        row=sheet.createRow(excel_Row);
        excel_Row++;
    }
    public void creatExcelCell(String value){
        HSSFCell cell=row.createCell(excel_Cell);
        excel_Cell++;
        cell.setCellValue(value);
    }
    public void excelSave(){
        try {
            file.setWritable(true, false);
            file.setReadable(true,false);
            file.setExecutable(true, false);
            FileOutputStream outputStream=new FileOutputStream(file);
            workbook.write(outputStream);
            outputStream.flush();
            outputStream.close();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
