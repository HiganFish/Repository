#include <string>
#include <QMessageBox>

#include <cmath>
#include "QtCalculator.h"

QtCalculator::QtCalculator(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    connect(ui.num_0, SIGNAL(clicked()), this, SLOT(ClickNum0()));
    connect(ui.num_1, SIGNAL(clicked()), this, SLOT(ClickNum1()));
    connect(ui.num_2, SIGNAL(clicked()), this, SLOT(ClickNum2()));
    connect(ui.num_3, SIGNAL(clicked()), this, SLOT(ClickNum3()));
    connect(ui.num_4, SIGNAL(clicked()), this, SLOT(ClickNum4()));
    connect(ui.num_5, SIGNAL(clicked()), this, SLOT(ClickNum5()));
    connect(ui.num_6, SIGNAL(clicked()), this, SLOT(ClickNum6()));
    connect(ui.num_7, SIGNAL(clicked()), this, SLOT(ClickNum7()));
    connect(ui.num_8, SIGNAL(clicked()), this, SLOT(ClickNum8()));
    connect(ui.num_9, SIGNAL(clicked()), this, SLOT(ClickNum9()));
    connect(ui.button_add, SIGNAL(clicked()), this, SLOT(ClickButtonAdd()));
    connect(ui.button_sub, SIGNAL(clicked()), this, SLOT(ClickButtonSub()));
    connect(ui.button_mult, SIGNAL(clicked()), this, SLOT(ClickButtonMult()));
    connect(ui.button_div, SIGNAL(clicked()), this, SLOT(ClickButtonDiv()));

    connect(ui.button_point, SIGNAL(clicked()), this, SLOT(ClickButtonPoint()));
    connect(ui.button_del, SIGNAL(clicked()), this, SLOT(ClickButtonDel()));

    connect(ui.button_result, SIGNAL(clicked()), this, SLOT(ClickButtonResult()));

    connect(ui.button_clear, SIGNAL(clicked()), this, SLOT(ClickButtonClear()));

    connect(ui.button_left, SIGNAL(clicked()), this, SLOT(ClickButtonLeft()));
    connect(ui.button_right, SIGNAL(clicked()), this, SLOT(ClickButtonRight()));

    connect(ui.button_pow, SIGNAL(clicked()), this, SLOT(ClickButtonPow()));
    connect(ui.button_mod, SIGNAL(clicked()), this, SLOT(ClickButtonMod()));
    connect(ui.button_sqrt, SIGNAL(clicked()), this, SLOT(ClickButtonSqrt()));
    connect(ui.button_sin, SIGNAL(clicked()), this, SLOT(ClickButtonSin()));
    connect(ui.button_cos, SIGNAL(clicked()), this, SLOT(ClickButtonCos()));
}

void QtCalculator::PrintfToBox(std::string message)
{
    QMessageBox::StandardButton info;
    info = QMessageBox::information(this, "message", message.c_str());
}

// ͳһclickʵ�ʴ�������, ���㴦��
void QtCalculator::ClickProcess(char code)
{
    // �ж��Ƿ�Ϊһ������Ŀ�ʼ, ������ΰ��µĲ��ǵ��ں�(��ֹ�û���ΰ��µ��ڵ��µ�bug)
    //if (core->first_click)
    //{
    //    // ���Ϊ��һ������, �����֮ǰ��ջ
    //    if (core)
    //    {
    //        delete core;
    //    }
    //    core = new calculator();
    //    // ��ս����
    //    clickbuttonclear();
    //}

    // ���������Ϊ��һ�� ��Ϊfalse
    // core->first_click = false;

    core->AddToStack(code);
    if (code == 'c')
    {
        ui.label_result->setText(ui.label_result->text() + "cos");
    }
    else if (code == 's')
    {
        ui.label_result->setText(ui.label_result->text() + "sin");
    }
    else
    {
        ui.label_result->setText(ui.label_result->text() + code);
    }
}

void QtCalculator::ClickNum0()
{
    ClickProcess('0');

}

void QtCalculator::ClickNum1()
{
    ClickProcess('1');

}

void QtCalculator::ClickNum2()
{
    ClickProcess('2');

}

void QtCalculator::ClickNum3()
{
    ClickProcess('3');
}

void QtCalculator::ClickNum4()
{
    ClickProcess('4');
}

void QtCalculator::ClickNum5()
{
    ClickProcess('5');
}

void QtCalculator::ClickNum6()
{
    ClickProcess('6');
}

void QtCalculator::ClickNum7()
{
    ClickProcess('7');
}

void QtCalculator::ClickNum8()
{
    ClickProcess('8');
}

void QtCalculator::ClickNum9()
{
    ClickProcess('9');
}

void QtCalculator::ClickButtonAdd()
{
    ClickProcess('+');
}

void QtCalculator::ClickButtonSub()
{
    ClickProcess('-');
}

void QtCalculator::ClickButtonMult()
{
    ClickProcess('*');
}

void QtCalculator::ClickButtonDiv()
{
    ClickProcess('/');
}

void QtCalculator::ClickButtonPow()
{
    ClickProcess('^');
}

void QtCalculator::ClickButtonMod()
{
    ClickProcess('%');
}

void QtCalculator::ClickButtonSqrt()
{
    double result = sqrt(core->GetResult());
    core->first_click = false;
    int result1 = floor(result);
    if (result - floor(result) < eps)
    {
        ui.label_result->setText(std::to_string(result1).c_str());
    }
    else
    {
        std::string final_result = std::to_string(result);
        int index = final_result.length() - 1;

        if (final_result[index] == '0')
        {
            while (index >= 1)
            {
                if (final_result[index] == '0' && final_result[index - 1] != '0')
                {
                    break;
                }
                index--;
            }
        }

        final_result = final_result.substr(0, index);
        ui.label_result->setText(final_result.c_str());
    }
}

void QtCalculator::ClickButtonSin()
{
    ClickProcess('s');
}

void QtCalculator::ClickButtonCos()
{
    ClickProcess('c');
}

void QtCalculator::ClickButtonPoint()
{
    ClickProcess('.');
}

void QtCalculator::ClickButtonDel()
{

    core->DelFromStack();

    std::string origin_text = ui.label_result->text().toStdString();
    std::string new_text = origin_text.substr(0, origin_text.length() - 1);

    ui.label_result->setText(new_text.c_str());
}

void QtCalculator::ClickButtonResult()
{
    // ���Ƶ�������λ
    std::string origin_text = ui.label_result->text().toStdString();
    ui.label_input->setText(origin_text.c_str());

    double result = core->GetResult();
    core->first_click = false;
    int result1 = floor(result);
    if (result - floor(result) < eps)
    {
        ui.label_result->setText(std::to_string(result1).c_str());
    }
    else
    {
        std::string final_result = std::to_string(result);
        int index = final_result.length() - 1;

        if (final_result[index] == '0')
        {
            while (index >= 1)
            {
                if (final_result[index] == '0' && final_result[index - 1] != '0')
                {
                    break;
                }
                index--;
            }
        }
        
        final_result = final_result.substr(0, index);
        ui.label_result->setText(final_result.c_str());
    }
    
}

void QtCalculator::ClickButtonClear()
{
    core->ClearStack();
    core->first_click = true;
    ui.label_result->setText("");
}

void QtCalculator::ClickButtonLeft()
{
    ClickProcess('(');
}

void QtCalculator::ClickButtonRight()
{
    ClickProcess(')');
}