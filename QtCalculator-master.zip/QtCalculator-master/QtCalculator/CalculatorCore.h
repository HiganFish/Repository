#pragma once
#include <stack>
#include <map>

class Calculator
{
public:
    bool first_click = false;

    Calculator();

    void AddToStack(char code);
    void DelFromStack();
    void ClearStack();

    void OtherStackProcess();
    double GetResult();
    void TestStack();
    double Calculate();

    double PopBackMainStack();
    char PopBackOtherStack();

    void ResetStack();
private:
    std::stack<double> main_stack{};
    std::stack<int> other_stack{};

    std::stack<double> main_stack_temp{};
    std::stack<int> other_stack_temp{};

    double temp = 0;

    bool is_number_input = true;

    bool is_integer = true;
    int sub_flag = -1;

    static bool enable_test;

    std::map<int, int> operator_to_level{ {'+', 1}, {'-', 2}, {'*', 3}, {'/', 4} ,{'^', 5} ,{'%', 6} ,{'s', 7} ,{'c', 8} };
    int operator_level_up = operator_to_level.size() + 1;
    short max_level;

    bool last_is_operator = false;
};