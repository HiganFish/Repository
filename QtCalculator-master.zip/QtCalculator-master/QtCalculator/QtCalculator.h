#pragma once

#include <QtWidgets/QMainWindow>
#include <QMessageBox>
#include "CalculatorCore.h"
#include "ui_QtCalculator.h"

class QtCalculator : public QMainWindow
{
    Q_OBJECT

public:
    QtCalculator(QWidget *parent = Q_NULLPTR);

    void PrintfToBox(std::string);

public slots:
    void ClickNum0();
    void ClickNum1();
    void ClickNum2();
    void ClickNum3();
    void ClickNum4();
    void ClickNum5();
    void ClickNum6();
    void ClickNum7();
    void ClickNum8();
    void ClickNum9();

    void ClickButtonAdd();
    void ClickButtonSub();
    void ClickButtonMult();
    void ClickButtonDiv();
    void ClickButtonPow();
    void ClickButtonMod();
    void ClickButtonSqrt();
    void ClickButtonSin();
    void ClickButtonCos();

    void ClickButtonPoint();
    void ClickButtonDel();
    void ClickButtonResult();
    void ClickButtonClear();

    void ClickButtonLeft();
    void ClickButtonRight();

private:
    void ClickProcess(char);

    double eps = 1e-10;

    Ui::QtCalculatorClass ui;
    Calculator* core = new Calculator();
};
