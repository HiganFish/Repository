#include <cerrno>

#include "CalculatorCore.h"
#include "QtCalculator.h"
#include <cmath>

# define M_PI 3.14159265358979323846

bool Calculator::enable_test = true;

Calculator::Calculator()
{
}

void Calculator::AddToStack(char code)
{
    last_is_operator = false;

    if (is_integer && code >= '0' && code <= '9')
    {
        temp = temp * 10 + code - '0';
        return;
    }

    if (code == '.')
    {
        is_integer = false;
        sub_flag = -1;
        return;
    }

    if (code >= '0' && code <= '9')
    {
        temp = temp + pow(10, sub_flag) * (code - '0');

        sub_flag--;
        return;
    }

    // ���һ�������������Ϊ��������
    if (code != '(' && code != ')' && code != 's' && code != 'c')
    {
        if (first_click)
        {
            is_integer = true;
            main_stack.push(temp);
            temp = 0;
        }
        else
        {
            is_integer = true;
            first_click = true;
            temp = 0;
        }
    }
    other_stack.push(code);

    last_is_operator = true;
}

void Calculator::DelFromStack()
{
    if (last_is_operator)
    {
        other_stack.pop();
    }
    else
    {
        main_stack.pop();
    }
    
}

void Calculator::ClearStack()
{
    
    while (!main_stack.empty())
    {
        main_stack.pop();
    }

    while (!other_stack.empty())
    {
        other_stack.pop();
    }

    while (!main_stack_temp.empty())
    {
        main_stack_temp.pop();
    }

    while (!other_stack_temp.empty())
    {
        other_stack_temp.pop();
    }
}

// �������ջ�е������ת������Ӧ�����ȼ�, �Ż�ջ��
void Calculator::OtherStackProcess()
{
    while (!other_stack.empty())
    {
        other_stack_temp.push(other_stack.top());
        other_stack.pop();
    }

    short level_up = 0;

    while (!other_stack_temp.empty())
    {
        int oper = other_stack_temp.top();
        other_stack_temp.pop();

        if (oper == ')')
        {
            level_up--;
            continue;
        }
        if (oper == '(')
        {
            level_up++;
            continue;
        }
        int level_temp = operator_to_level[oper] + level_up * operator_level_up;
        if (level_temp > max_level)
        {
            max_level = level_temp;
        }
        other_stack.push(level_temp);
    }
}

double Calculator::GetResult()
{

    // ѹ�����һ����ֵ
    if (first_click)
    {
        main_stack.push(temp);
    }
    
    temp = 0;

    // ����ջ������
    TestStack();

    return Calculate();
}

double Calculator::Calculate()
{
    
    char temp_operator;
    double temp_num_right = 0;
    double temp_num_left = 0;
    double temp_num_single = 0;
    
    // �� �����ȼ������
    bool has_oper = true;

    // ���������ջ
    OtherStackProcess();

    int level_temp = 0;

    while (!other_stack.empty() || !other_stack_temp.empty())
    {
        TestStack();

        temp_operator = other_stack.top();

        if (temp_operator > level_temp && temp_operator != max_level)
        {
            level_temp = temp_operator;
        }

        if (temp_operator == max_level)
        {
            int temp_a = temp_operator % operator_level_up;
            if (temp_a > 6)
            {
                temp_num_single = PopBackMainStack();
            }
            else
            {
                temp_num_right = PopBackMainStack();
                temp_num_left = PopBackMainStack();
            }

            switch (temp_a)
            {
            case 1:
                main_stack.push(temp_num_left + temp_num_right);
                break;
            case 2:
                main_stack.push(temp_num_left - temp_num_right);
                break;
            case 3:
                main_stack.push(temp_num_left * temp_num_right);
                break;
            case 4:
                main_stack.push(temp_num_left / temp_num_right);
                break;
            case 5:
                main_stack.push(std::pow(temp_num_left, temp_num_right));
                break;
            case 6:
                main_stack.push(std::fmod(temp_num_left, temp_num_right));
                break;
            case 7:
                main_stack.push(sin(temp_num_single * M_PI / 180));
                break;
            case 8:
                main_stack.push(cos(temp_num_single * M_PI / 180));
                break;
            }
            other_stack.pop();
        }
        else
        {
            other_stack_temp.push(PopBackOtherStack());
            main_stack_temp.push(PopBackMainStack());
        }

        if (other_stack.empty() && !other_stack_temp.empty())
        {
            max_level = level_temp;
            level_temp = 0;
            ResetStack();
        }
    }
    return main_stack.top();
}

void Calculator::TestStack()
{

    if (!enable_test)
    {
        return;
    }

    std::string message{};
    while (!main_stack.empty())
    {
        double last = PopBackMainStack();
        message = message + std::to_string(last) + "\r\n";
        main_stack_temp.push(last);
    }

    // ���������
    QtCalculator qt;
    qt.PrintfToBox("main_stack\r\n" + message);

    message = "";
    while (!other_stack.empty())
    {
        int last = PopBackOtherStack();
        message = message + std::to_string(last) + "\r\n";
        other_stack_temp.push(last);
    }

    qt.PrintfToBox("other_stack\r\n" + message);

    ResetStack();
}

double Calculator::PopBackMainStack()
{
    if (!main_stack.empty())
    {
        double temp = main_stack.top();
        main_stack.pop();
        return temp;
    }
    else
    {
        exit(0);
    }
}

char Calculator::PopBackOtherStack()
{
    if (!other_stack.empty())
    {
        double temp = other_stack.top();
        other_stack.pop();
        return temp;
    }
    else
    {
        exit(0);
    }
}

void Calculator::ResetStack()
{
    
    while (!other_stack_temp.empty())
    {
        other_stack.push(other_stack_temp.top());
        other_stack_temp.pop();
    }

    while (!main_stack_temp.empty())
    {
        main_stack.push(main_stack_temp.top());
        main_stack_temp.pop();
    }
}