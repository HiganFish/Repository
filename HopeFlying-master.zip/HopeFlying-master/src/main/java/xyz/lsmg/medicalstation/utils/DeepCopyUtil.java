package xyz.lsmg.medicalstation.utils;

import xyz.lsmg.medicalstation.entity.DroneStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName DeepCopyUtil
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/14 17:34
 * @Version 1.0
 **/
public class DeepCopyUtil {

    public static List<DroneStatus> listDeepCopy(List<DroneStatus> originList) {
        List<DroneStatus> droneStatusList = new ArrayList<>();
        for(DroneStatus droneStatus : originList) {
            droneStatusList.add((DroneStatus) droneStatus.clone());
        }

        return droneStatusList;
    }
}
