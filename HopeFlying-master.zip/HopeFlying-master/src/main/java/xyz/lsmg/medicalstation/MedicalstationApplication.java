package xyz.lsmg.medicalstation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class MedicalstationApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedicalstationApplication.class, args);
    }

}
