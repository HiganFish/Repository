package xyz.lsmg.medicalstation.entity;

/**
 * @ClassName LoginInfo
 * @Description TODO
 * Author lsmg
 * Date 2019/7/14 11:59
 * @Version 1.0
 **/
public class LoginInfo {
    String username;
    String info;

    public LoginInfo() {
    }

    public LoginInfo(String username, String info) {
        this.username = username;
        this.info = info;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
