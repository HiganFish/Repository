package xyz.lsmg.medicalstation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import xyz.lsmg.medicalstation.entity.LoginInfo;

/**
 * @ClassName IndexController
 * @Description TODO
 * Author lsmg
 * Date 2019/7/14 11:50
 * @Version 1.0
 **/

@Controller
public class IndexController {
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String index() {
        return "login";
    }

    @ResponseBody
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public LoginInfo login(String username, String password) {

        LoginInfo loginInfo = new LoginInfo();

        if(username != null && password !=null) {
            if(username.equals(password)) {
                loginInfo.setInfo("success");
            } else {
                loginInfo.setInfo("failure");
            }
        }

        loginInfo.setUsername("admin");

        return loginInfo;
    }

    @RequestMapping(value = "/toMain", method = RequestMethod.POST)
    public String toMainPage(String key) {

        if(key != null) {
            return "test";
        }

        return "login";
    }

}
