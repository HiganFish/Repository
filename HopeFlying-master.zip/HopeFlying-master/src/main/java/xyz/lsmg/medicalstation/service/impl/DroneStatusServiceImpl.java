package xyz.lsmg.medicalstation.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import xyz.lsmg.medicalstation.entity.DroneStatus;
import xyz.lsmg.medicalstation.service.DroneStatusService;
import xyz.lsmg.medicalstation.utils.DeepCopyUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName DroneStatusServiceImpl
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/14 15:57
 * @Version 1.0
 **/

@Service("droneStatusService")
public class DroneStatusServiceImpl implements DroneStatusService {

    private Logger logger = LoggerFactory.getLogger(DroneStatusServiceImpl.class);

    private List<DroneStatus> droneStatusList = new ArrayList<>();
    private static double lastPrecision = 117.184811;
    private static double lastLatitude = 34.261792;

    @Override
    @Scheduled(fixedRate = 1000)
    public void generateDroneStatus() {
        lastPrecision += (Math.random()-0.5)*0.0001;
        lastLatitude += (Math.random()-0.5)*0.0001;

        DroneStatus droneStatus = new DroneStatus(lastPrecision, lastLatitude);
        logger.info(droneStatus.toString());

        droneStatusList.add(droneStatus);
    }

    @Override
    public List<DroneStatus> listDroneStatus() {

        List<DroneStatus> theDroneStatusList = DeepCopyUtil.listDeepCopy(droneStatusList);
        droneStatusList.clear();
        logger.info("清除一次信息list共"+theDroneStatusList.size()+"条");

        return theDroneStatusList;
    }
}
