package xyz.lsmg.medicalstation.entity;

/**
 * @ClassName DroneStatus
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/14 15:44
 * @Version 1.0
 **/
public class DroneStatus implements Cloneable{
    /**经度**/
    private double precision;
    /**纬度**/
    private double latitude;

    public DroneStatus() {
    }

    public DroneStatus(double precision, double latitude) {
        this.precision = precision;
        this.latitude = latitude;
    }

    public double getPrecision() {
        return precision;
    }

    public void setPrecision(double precision) {
        this.precision = precision;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    @Override
    public String toString() {
        return "DroneStatus{" +
                "precision=" + precision +
                ", latitude=" + latitude +
                '}';
    }

    @Override
    public Object clone() {
        DroneStatus droneStatus = null;
        try {
            droneStatus = (DroneStatus) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return droneStatus;

    }
}
