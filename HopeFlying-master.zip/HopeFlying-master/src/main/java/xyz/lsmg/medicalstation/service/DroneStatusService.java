package xyz.lsmg.medicalstation.service;

import xyz.lsmg.medicalstation.entity.DroneStatus;

import java.util.List;

/**
 * @ClassName DroneStatusService
 * @Description TODO
 * Author lsmg
 * Date 2019/7/14 15:49
 * @Version 1.0
 **/
public interface DroneStatusService {

    /**
     * @Author lsmg
     * @Description
     * 生成无人机状态
     * @Date 15:52 2019/7/14
     * @param
     * @return void
    **/
    void generateDroneStatus();

    /**
     * @Author lsmg
     * @Description
     * 获取无人机状态list
     * @Date 15:52 2019/7/14
     * @param
     * @return java.util.List<xyz.lsmg.medicalstation.entity.DroneStatus>
    **/
    List<DroneStatus> listDroneStatus();


}
