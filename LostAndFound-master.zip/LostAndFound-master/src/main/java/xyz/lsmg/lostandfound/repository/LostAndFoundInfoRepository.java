package xyz.lsmg.lostandfound.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xyz.lsmg.lostandfound.domain.LostAndFoundInfo;

import java.util.Date;
import java.util.List;

/**
 * @ClassName LostAndFoundInfoRepository
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 23:11
 * @Version 1.0
 **/
public interface LostAndFoundInfoRepository extends JpaRepository<LostAndFoundInfo, Long> {

	LostAndFoundInfo findById(long id);

	List<LostAndFoundInfo> findByPublisherIdBefore(Date date);

	List<LostAndFoundInfo> findByPublishtimeBefore(Date date);
}
