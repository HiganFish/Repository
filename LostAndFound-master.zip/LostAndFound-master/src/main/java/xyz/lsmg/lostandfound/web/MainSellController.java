package xyz.lsmg.lostandfound.web;

import io.swagger.annotations.*;
import net.coobird.thumbnailator.Thumbnails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import xyz.lsmg.lostandfound.common.Const;
import xyz.lsmg.lostandfound.domain.LostAndFoundInfo;
import xyz.lsmg.lostandfound.domain.result.ExceptionMsg;
import xyz.lsmg.lostandfound.domain.result.ResponseData;
import xyz.lsmg.lostandfound.repository.LostAndFoundInfoRepository;
import xyz.lsmg.lostandfound.utils.ImageUtil;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.UUID;


/**
 * @ClassName MainController
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 20:05
 * @Version 1.0
 **/

@RestController
@RequestMapping("/api/sell")
@Api(value = "主体api部分")
public class MainSellController {

	@Autowired
	LostAndFoundInfoRepository lostAndFoundInfoRepository;

	DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy_MM_dd");

	private Logger logger = LoggerFactory.getLogger(MainSellController.class);

	/**
	 * @Author lsmg
	 * @Description 发布新信息
	 * @Date 16:03 2019/7/21
	 * @param newLostAndFoundInfo 信息实体类
	 * @param imgs 图片信息
	 * @return xyz.lsmg.lostandfound.domain.result.ResponseData
	**/
	@RequestMapping(value = "/publishNewMsg", method = RequestMethod.POST)
	@ApiOperation(value = "新增失物招领信息")
	@ApiImplicitParams ({
		@ApiImplicitParam(paramType="query", name = "publisherId", value = "发布者id, 此id会用于发布者删除时的身份验证", required = true),
		@ApiImplicitParam(paramType="query", name = "title", value = "寻物主题", required = true),
		@ApiImplicitParam(paramType="query", name = "describe", value = "物品描述", required = true),
		@ApiImplicitParam(paramType="query", name = "place", value = "遗失(拾取)地点", required = true),
		@ApiImplicitParam(paramType="query", name = "picktime", value = "遗失(拾取)时间", required = true),
		@ApiImplicitParam(paramType="query", name = "contactName", value = "联系人", required = true),
		@ApiImplicitParam(paramType="query", name = "contactNumber", value = "联系方式", required = true),
		@ApiImplicitParam(paramType="query", name = "lostthings", value = "1为寻物启事2为失物招领", required = true)
	})
	public ResponseData listClassmates (LostAndFoundInfo newLostAndFoundInfo,
	                                    @ApiParam(value = "上传的文件(请使用POSTMAN测试文件上传, 否则只能在listAllMsg看到imagelist属性)", required = false)
	                                    @RequestParam(value = "imgs", required = false) MultipartFile[] imgs) {

		String publisherId = newLostAndFoundInfo.getPublisherId();

		if(null != imgs) {
			for(MultipartFile img : imgs) {
				String dirUrl = Const.UPLOAD_IMAGE_PATH + File.separator;
				String singlePart = dateTimeFormatter.format(LocalDateTime.now())+ "_" +publisherId + "_" + UUID.randomUUID().toString().subSequence(0, 8)  + ".jpg";
				String pathUrl = dirUrl + singlePart ;

				try{
					byte[] bytes = img.getBytes();
					Path path = Paths.get(pathUrl);

					Files.write(path, bytes);

					newLostAndFoundInfo.addImagesToList(Const.DOWNLOAD_IMAGE_PREFIX + singlePart);
					Thumbnails.of(pathUrl).scale(1f).outputQuality(0.5f).toFile(pathUrl);

				} catch (Exception e) {
					logger.warn(publisherId + " 发布" + newLostAndFoundInfo.toString() + "失败");
					e.printStackTrace();
					return new ResponseData(ExceptionMsg.UPLOAD_FAILED);
				}

			}
		}

		logger.info(publisherId + " 发布" + newLostAndFoundInfo.toString() + "成功");

		lostAndFoundInfoRepository.save(newLostAndFoundInfo);

		return new ResponseData(ExceptionMsg.SUCCESS, newLostAndFoundInfo);
	}


	@ApiOperation(value = "查询所有信息")
	@RequestMapping(value = "/listAllMsg", method = RequestMethod.GET)
	public ResponseData listAllMsg() {

		List<LostAndFoundInfo> lostAndFoundInfoList = lostAndFoundInfoRepository.findAll();
		Collections.reverse(lostAndFoundInfoList);

		return  new ResponseData(ExceptionMsg.SUCCESS, lostAndFoundInfoList);
	}

	@ApiOperation(value = "查询指定id的信息")
	@ApiImplicitParam(paramType = "query", name = "id", value = "此条信息的id", required = true)
	@RequestMapping(value = "/getMsgById", method = RequestMethod.GET)
	public ResponseData getMsgById(Long id) {

		if(null == id) {
			return new ResponseData(ExceptionMsg.FAILED_ID_IS_NULL);
		}

		LostAndFoundInfo lostAndFoundInfo = lostAndFoundInfoRepository.findById(id.longValue());

		if(null == lostAndFoundInfo) {
			return new ResponseData(ExceptionMsg.USER_NOTEXIST);
		}

		return  new ResponseData(ExceptionMsg.SUCCESS, lostAndFoundInfo);
	}

	@ApiOperation(value = "根据id删除信息(需提供请求发起者学号)")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "id", value = "此条信息id", required = true),
			@ApiImplicitParam(paramType = "query", name = "requesterId", value = "请求发起者id", required = true)
	})
	@RequestMapping(value = "/delMsgById", method = RequestMethod.GET)
	public ResponseData delMsgById(Long id, String requesterId) {

		logger.info("接收到请求： id为" + id +"-请求id为" + requesterId);

		if(null == id) {
			logger.info("接收到请求： id为空");
			return new ResponseData(ExceptionMsg.FAILED_ID_IS_NULL);
		}

		LostAndFoundInfo lostAndFoundInfo = lostAndFoundInfoRepository.findById(id.longValue());
		if(null == lostAndFoundInfo) {
			logger.info("接收到请求： id无法查询到对应信息");
			return new ResponseData(ExceptionMsg.DEL_FAILED);
		}

		if(lostAndFoundInfo.getPublisherId().equals(requesterId)) {

			ImageUtil.delImgesByInfo(lostAndFoundInfo);

			lostAndFoundInfoRepository.deleteById(id);
			return new ResponseData(ExceptionMsg.SUCCESS);

		}

		logger.info("发送： " + requesterId + "验证为： " + lostAndFoundInfo.getPublisherId());

		return new ResponseData(ExceptionMsg.DEL_FAILED);
	}
}
