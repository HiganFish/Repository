package xyz.lsmg.lostandfound.domain;

import com.alibaba.fastjson.JSON;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @ClassName LostAndFoundInfo
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 20:21
 * @Version 1.0
 **/

@ApiModel(description = "data部分")
@Entity(name = "LostAndFoundInfo")
public class LostAndFoundInfo implements Serializable {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@ApiModelProperty(hidden = true)
	private long id;

	@ApiModelProperty(hidden = true)
	@Column(name = "publishtime")
	private Date publishtime;

	@ApiModelProperty(value = "1为寻物启事, 2为失物招领")
	private int lostthings;

	public int getLostthings() {
		return lostthings;
	}

	public void setLostthings(int lostthings) {
		this.lostthings = lostthings;
	}

	@Column(name = "publisherid")
	private String publisherId;

	private String title;
	@Column(name = "objectdescribe")
	private String describe;

	@ApiModelProperty(hidden = true)
	@Transient
	private List<String> images = new ArrayList<>();

	@ApiModelProperty(hidden = true)
	@Column(name = "imagestring")
	private String imageString;

	@ApiModelProperty(hidden = true)
	@Transient
	private String[] imagelist;

	@Column(name = "place")
	private String place;
	@Column(name = "picktime")
	private String picktime;
	@Column(name = "contactname")
	private String contactName;
	@Column(name = "contactnumber")
	private String contactNumber;

	public void addImagesToList(String imageUrl) {
		images.add(imageUrl);
		imageString = JSON.toJSONString(images);
	}

	public LostAndFoundInfo() {

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		publishtime = calendar.getTime();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String[] getImagelist() {
		if(null == imageString) {
			return null;
		}
		imageString = imageString.replaceAll("\"","");
		System.out.println(imageString);
		imagelist = imageString.substring(1, imageString.length()-1).split(",");
		return imagelist;
	}



	public String getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(String publisherId) {
		this.publisherId = publisherId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescribe() {
		return describe;
	}

	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getPicktime() {
		return picktime;
	}

	public void setPicktime(String picktime) {
		this.picktime = picktime;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "{" +
				"id=" + id +
				", publisherId='" + publisherId + '\'' +
				", title='" + title + '\'' +
				", describe='" + describe + '\'' +
				", imagelist='" + imagelist + '\'' +
				", place='" + place + '\'' +
				", picktime='" + picktime + '\'' +
				", contactName='" + contactName + '\'' +
				", contactNumber='" + contactNumber + '\'' +
				'}';
	}
}
