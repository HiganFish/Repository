package xyz.lsmg.lostandfound.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import xyz.lsmg.lostandfound.domain.LostAndFoundInfo;
import xyz.lsmg.lostandfound.repository.LostAndFoundInfoRepository;
import xyz.lsmg.lostandfound.utils.ImageUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @ClassName ScheduleTasks
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/21 16:39
 * @Version 1.0
 **/

@Component
public class ScheduleTasks {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	LostAndFoundInfoRepository lostAndFoundInfoRepository;

	/** 定时删除超时两个月的信息*/
	@Scheduled(cron = "0 0 3 1/1 * ?")
	public void autoClear() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.DAY_OF_MONTH, -60);

		List<LostAndFoundInfo> lostAndFoundInfoList = lostAndFoundInfoRepository.findByPublishtimeBefore(calendar.getTime());

		for(LostAndFoundInfo lostAndFoundInfo : lostAndFoundInfoList) {

			logger.info("定时删除: " + lostAndFoundInfo);
			lostAndFoundInfoRepository.deleteById(lostAndFoundInfo.getId());
			ImageUtil.delImgesByInfo(lostAndFoundInfo);

		}
	}
}
