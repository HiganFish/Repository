package xyz.lsmg.lostandfound.common;

import org.springframework.stereotype.Component;

import java.io.File;

/**
 * @ClassName Const
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 22:20
 * @Version 1.0
 **/
@Component
public class Const {

	public static final String UPLOAD_IMAGE_PATH = System.getProperty("user.dir") + File.separator + "imgs";
	private static final String DOWNLOAD_IMAGE_URL = "https://find.lsmg.xyz/";
	public static final String DOWNLOAD_IMAGE_PREFIX = DOWNLOAD_IMAGE_URL  + "imgs/";

}
