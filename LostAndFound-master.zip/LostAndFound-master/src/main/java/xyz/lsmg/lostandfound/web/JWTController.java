package xyz.lsmg.lostandfound.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName JWTController
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/23 10:37
 * @Version 1.0
 **/

@RestController
@RequestMapping("/JWT")
public class JWTController {

}
