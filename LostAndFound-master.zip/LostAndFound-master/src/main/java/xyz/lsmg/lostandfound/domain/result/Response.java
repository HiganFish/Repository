package xyz.lsmg.lostandfound.domain.result;

import io.swagger.annotations.ApiModelProperty;

/**
 * @ClassName Response
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 19:59
 * @Version 1.0
 **/

public class Response {
	/** 返回信息码*/
	@ApiModelProperty(value = "成功返回1, 失败返回-1")
	private int status =1;
	/** 返回信息内容*/
	private String msg = "操作成功";


	public Response() {
	}

	public Response(ExceptionMsg msg){
		this.status = msg.getCode();
		this.msg =msg.getMsg();
	}

	public Response(int rspCode) {
		this.status = rspCode;
		this.msg = "";
	}

	public Response(int rspCode, String rspMsg) {
		this.status = rspCode;
		this.msg = rspMsg;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}


	@Override
	public String toString() {
		return "Response{" +
				"status='" + status + '\'' +
				", msg='" + msg + '\'' +
				'}';
	}
}
