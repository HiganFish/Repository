package xyz.lsmg.secondtranslate.web;

import io.swagger.annotations.*;
import net.coobird.thumbnailator.Thumbnails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import xyz.lsmg.secondtranslate.common.Const;
import xyz.lsmg.secondtranslate.domain.SecondTranslateBuyInfo;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;
import xyz.lsmg.secondtranslate.domain.result.ExceptionMsg;
import xyz.lsmg.secondtranslate.domain.result.ResponseData;
import xyz.lsmg.secondtranslate.repository.SecondTranslateBuyInfoRepository;
import xyz.lsmg.secondtranslate.repository.SecondTranslateSellInfoRepository;
import xyz.lsmg.secondtranslate.utils.ImageUtil;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.UUID;


/**
 * @ClassName MainController
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 20:05
 * @Version 1.0
 **/

@RestController
@RequestMapping("/api/buy")
@Api(value = "主体api部分")
public class MainBuyController {

	@Autowired
	SecondTranslateBuyInfoRepository secondTranslateBuyInfoRepository;

	DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy_MM_dd");

	private Logger logger = LoggerFactory.getLogger(MainBuyController.class);

	/**
	 * @Author lsmg
	 * @Description 发布新信息
	 * @Date 16:03 2019/7/21
	 * @param newSecondTranslateBuyInfo 信息实体类
	 * @return xyz.lsmg.secondtranslate.domain.result.ResponseData
	**/
	@RequestMapping(value = "/publishNewMsg", method = RequestMethod.POST)
	@ApiOperation(value = "新增求购信息")
	@ApiImplicitParams ({
		@ApiImplicitParam(paramType="query", name = "publisherId", value = "发布者id, 此id会用于发布者删除时的身份验证", required = true),
		@ApiImplicitParam(paramType="query", name = "title", value = "发布标题", required = true),
		@ApiImplicitParam(paramType="query", name = "describe", value = "物品描述", required = true),
		@ApiImplicitParam(paramType="query", name = "price", value = "物品价格", required = true),
		@ApiImplicitParam(paramType="query", name = "contactQQ", value = "QQ号", required = true),
		@ApiImplicitParam(paramType="query", name = "contactWechat", value = "微信号", required = true),
		@ApiImplicitParam(paramType="query", name = "objectType", value = "1图书音像，2办公文体，3生活用品，4电子数码，5其它", required = true)
	})
	public ResponseData listClassmates (SecondTranslateBuyInfo newSecondTranslateBuyInfo) {

		String publisherId = newSecondTranslateBuyInfo.getPublisherId();


		logger.info(publisherId + " 发布" + newSecondTranslateBuyInfo.toString() + "成功");

		secondTranslateBuyInfoRepository.save(newSecondTranslateBuyInfo);

		return new ResponseData(ExceptionMsg.SUCCESS, newSecondTranslateBuyInfo);
	}


	@ApiOperation(value = "查询所有信息")
	@RequestMapping(value = "/listAllMsg", method = RequestMethod.GET)
	public ResponseData listAllMsg() {

		List<SecondTranslateBuyInfo> secondTranslateSellInfoList = secondTranslateBuyInfoRepository.findAll();
		Collections.reverse(secondTranslateSellInfoList);

		return  new ResponseData(ExceptionMsg.SUCCESS, secondTranslateSellInfoList);
	}

	@ApiOperation(value = "查询指定id的信息")
	@ApiImplicitParam(paramType = "query", name = "id", value = "此条信息的id", required = true)
	@RequestMapping(value = "/getMsgById", method = RequestMethod.GET)
	public ResponseData getMsgById(Long id) {

		if(null == id) {
			return new ResponseData(ExceptionMsg.FAILED_ID_IS_NULL);
		}

		SecondTranslateBuyInfo secondTranslateBuyInfo = secondTranslateBuyInfoRepository.findById(id.longValue());

		if(null == secondTranslateBuyInfo) {
			return new ResponseData(ExceptionMsg.USER_NOTEXIST);
		}

		return  new ResponseData(ExceptionMsg.SUCCESS, secondTranslateBuyInfo);
	}

}
