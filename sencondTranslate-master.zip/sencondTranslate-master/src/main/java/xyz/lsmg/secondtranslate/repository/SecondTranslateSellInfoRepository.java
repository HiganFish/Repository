package xyz.lsmg.secondtranslate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;

import java.util.Date;
import java.util.List;

/**
 * @ClassName SecondTranslateSellInfoRepository
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 23:11
 * @Version 1.0
 **/
public interface SecondTranslateSellInfoRepository extends JpaRepository<SecondTranslateSellInfo, Long> {

	SecondTranslateSellInfo findById(long id);

	List<SecondTranslateSellInfo> findByPublisherIdBefore(Date date);

	List<SecondTranslateSellInfo> findByPublishtimeBefore(Date date);

	List<SecondTranslateSellInfo> findAllByPublisherId(String username);
}
