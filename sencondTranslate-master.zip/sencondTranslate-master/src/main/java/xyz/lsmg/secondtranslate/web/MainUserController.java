package xyz.lsmg.secondtranslate.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import xyz.lsmg.secondtranslate.domain.SecondTranslateBuyInfo;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;
import xyz.lsmg.secondtranslate.domain.result.ExceptionMsg;
import xyz.lsmg.secondtranslate.domain.result.ResponseData;
import xyz.lsmg.secondtranslate.repository.SecondTranslateBuyInfoRepository;
import xyz.lsmg.secondtranslate.repository.SecondTranslateSellInfoRepository;
import xyz.lsmg.secondtranslate.utils.ImageUtil;

import java.util.List;

/**
 * @ClassName MainUserController
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/30 18:58
 * @Version 1.0
 **/

@RestController
@RequestMapping("/api/user")
@Api(value = "主体api部分")
public class MainUserController {

	@Autowired
	SecondTranslateBuyInfoRepository secondTranslateBuyInfoRepository;

	@Autowired
	SecondTranslateSellInfoRepository secondTranslateSellInfoRepository;

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@ApiOperation(value = "根据id删除信息(需提供请求发起者学号)")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "id", value = "此条信息id", required = true),
			@ApiImplicitParam(paramType = "query", name = "requesterId", value = "请求发起者id", required = true),
			@ApiImplicitParam(paramType = "query", name = "isSell", value = "Sell表示删除售卖信息, Buy表示删除求购信息", required = true)
	})
	@RequestMapping(value = "/delMsgById", method = RequestMethod.GET)
	public ResponseData delMsgById(String isSell, Long id, String requesterId) {


		if(null == id) {
			logger.info("接收到请求： id为空");
			return new ResponseData(ExceptionMsg.FAILED_ID_IS_NULL);
		}

		if("Sell".equals(isSell)) {
			SecondTranslateSellInfo secondTranslateSellInfo = secondTranslateSellInfoRepository.findById(id.longValue());
			if(null == secondTranslateSellInfo) {
				logger.info("接收到请求： id无法查询到对应信息");
				return new ResponseData(ExceptionMsg.DEL_FAILED);
			}

			if(secondTranslateSellInfo.getPublisherId().equals(requesterId)) {

				ImageUtil.delImgesByInfo(secondTranslateSellInfo);

				secondTranslateSellInfoRepository.deleteById(id);
				return new ResponseData(ExceptionMsg.SUCCESS);

			}

			logger.info("发送： " + requesterId + "验证为： " + secondTranslateSellInfo.getPublisherId());
		}

		if("Buy".equals(isSell)) {
			SecondTranslateBuyInfo secondTranslateBuyInfo = secondTranslateBuyInfoRepository.findById(id.longValue());
			if(null == secondTranslateBuyInfo) {
				logger.info("接收到请求： id无法查询到对应信息");
				return new ResponseData(ExceptionMsg.DEL_FAILED);
			}

			if(secondTranslateBuyInfo.getPublisherId().equals(requesterId)) {

				secondTranslateBuyInfoRepository.deleteById(id);
				return new ResponseData(ExceptionMsg.SUCCESS);

			}

			logger.info("发送： " + requesterId + "验证为： " + secondTranslateBuyInfo.getPublisherId());
		}

		return new ResponseData(ExceptionMsg.DEL_FAILED);
	}

	@ApiOperation(value = "指定学号获取用户所有发布信息, 注意data部分为Object[2], Object[0]为求购, Object[1]为售卖")
	@RequestMapping(value = "/listUserAllInfo", method = RequestMethod.GET)

	public ResponseData listAllInfo(String username) {
		if(null == username) {
			return new ResponseData(ExceptionMsg.FAILED_GET_USERINFO);
		}

		Object[] result = new Object[2];
		result[0] = secondTranslateBuyInfoRepository.findAllByPublisherId(username);
		result[1] = secondTranslateSellInfoRepository.findAllByPublisherId(username);

		return new ResponseData(ExceptionMsg.SUCCESS, result);
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ResponseData searchInfo(String keyWords) {

	}
}
