package xyz.lsmg.secondtranslate.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import xyz.lsmg.secondtranslate.domain.SecondTranslateBuyInfo;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;
import xyz.lsmg.secondtranslate.repository.SecondTranslateBuyInfoRepository;
import xyz.lsmg.secondtranslate.repository.SecondTranslateSellInfoRepository;
import xyz.lsmg.secondtranslate.utils.ImageUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @ClassName ScheduleTasks
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/21 16:39
 * @Version 1.0
 **/

@Component
public class ScheduleTasks {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	SecondTranslateSellInfoRepository secondTranslateSellInfoRepository;

	@Autowired
	SecondTranslateBuyInfoRepository secondTranslateBuyInfoRepository;

	/** 定时删除超时两个月的信息*/
	@Scheduled(cron = "0 0 3 1/1 * ?")
	public void autoSellClear() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.DAY_OF_MONTH, -60);

		List<SecondTranslateSellInfo> secondTranslateSellInfoList = secondTranslateSellInfoRepository.findByPublishtimeBefore(calendar.getTime());

		for(SecondTranslateSellInfo secondTranslateSellInfo : secondTranslateSellInfoList) {

			logger.info("定时删除: " + secondTranslateSellInfo);
			secondTranslateSellInfoRepository.deleteById(secondTranslateSellInfo.getId());
			ImageUtil.delImgesByInfo(secondTranslateSellInfo);

		}
	}

	/** 定时删除超时两个月的信息*/
	@Scheduled(cron = "0 0 3 1/1 * ?")
	public void autoBuyClear() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.DAY_OF_MONTH, -60);

		List<SecondTranslateBuyInfo> secondTranslateSellInfoList = secondTranslateBuyInfoRepository.findByPublishtimeBefore(calendar.getTime());

		for(SecondTranslateBuyInfo secondTranslateBuyInfo : secondTranslateSellInfoList) {

			logger.info("定时删除: " + secondTranslateBuyInfo);
			secondTranslateBuyInfoRepository.deleteById(secondTranslateBuyInfo.getId());

		}
	}
}
