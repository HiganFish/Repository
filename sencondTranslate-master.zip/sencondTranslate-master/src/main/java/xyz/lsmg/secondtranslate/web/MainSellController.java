package xyz.lsmg.secondtranslate.web;

import io.swagger.annotations.*;
import net.coobird.thumbnailator.Thumbnails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import xyz.lsmg.secondtranslate.common.Const;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;
import xyz.lsmg.secondtranslate.domain.result.ExceptionMsg;
import xyz.lsmg.secondtranslate.domain.result.ResponseData;
import xyz.lsmg.secondtranslate.repository.SecondTranslateSellInfoRepository;
import xyz.lsmg.secondtranslate.utils.ImageUtil;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.UUID;


/**
 * @ClassName MainController
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 20:05
 * @Version 1.0
 **/

@RestController
@RequestMapping("/api/sell")
@Api(value = "主体api部分")
public class MainSellController {

	@Autowired
	SecondTranslateSellInfoRepository secondTranslateSellInfoRepository;

	DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy_MM_dd");

	private Logger logger = LoggerFactory.getLogger(MainSellController.class);

	/**
	 * @Author lsmg
	 * @Description 发布新信息
	 * @Date 16:03 2019/7/21
	 * @param newSecondTranslateSellInfo 信息实体类
	 * @param imgs 图片信息
	 * @return xyz.lsmg.secondtranslate.domain.result.ResponseData
	**/
	@RequestMapping(value = "/publishNewMsg", method = RequestMethod.POST)
	@ApiOperation(value = "新增售卖信息")
	@ApiImplicitParams ({
		@ApiImplicitParam(paramType="query", name = "publisherId", value = "发布者id, 此id会用于发布者删除时的身份验证", required = true),
		@ApiImplicitParam(paramType="query", name = "title", value = "发布标题", required = true),
		@ApiImplicitParam(paramType="query", name = "describe", value = "物品描述", required = true),
		@ApiImplicitParam(paramType="query", name = "price", value = "物品价格", required = true),
		@ApiImplicitParam(paramType="query", name = "contactQQ", value = "QQ号", required = true),
		@ApiImplicitParam(paramType="query", name = "contactWechat", value = "微信号", required = true),
	})
	public ResponseData listClassmates (SecondTranslateSellInfo newSecondTranslateSellInfo,
	                                    @ApiParam(value = "上传的文件(请使用POSTMAN测试文件上传, 否则只能在listAllMsg看到imagelist属性)", required = false)
	                                    @RequestParam(value = "imgs", required = false) MultipartFile[] imgs) {

		String publisherId = newSecondTranslateSellInfo.getPublisherId();

		if(null != imgs) {
			for(MultipartFile img : imgs) {
				String dirUrl = Const.UPLOAD_IMAGE_PATH + File.separator;
				String singlePart = dateTimeFormatter.format(LocalDateTime.now())+ "_" +publisherId + "_" + UUID.randomUUID().toString().subSequence(0, 8)  + ".jpg";
				String pathUrl = dirUrl + singlePart ;

				try{
					byte[] bytes = img.getBytes();
					Path path = Paths.get(pathUrl);

					Files.write(path, bytes);

					newSecondTranslateSellInfo.addImagesToList(Const.DOWNLOAD_IMAGE_PREFIX + singlePart);
					Thumbnails.of(pathUrl).scale(1f).outputQuality(0.5f).toFile(pathUrl);

				} catch (Exception e) {
					logger.warn(publisherId + " 发布" + newSecondTranslateSellInfo.toString() + "失败");
					e.printStackTrace();
					return new ResponseData(ExceptionMsg.UPLOAD_FAILED);
				}

			}
		}

		logger.info(publisherId + " 发布" + newSecondTranslateSellInfo.toString() + "成功");

		secondTranslateSellInfoRepository.save(newSecondTranslateSellInfo);

		return new ResponseData(ExceptionMsg.SUCCESS, newSecondTranslateSellInfo);
	}


	@ApiOperation(value = "查询所有信息")
	@RequestMapping(value = "/listAllMsg", method = RequestMethod.GET)
	public ResponseData listAllMsg() {

		List<SecondTranslateSellInfo> secondTranslateSellInfoList = secondTranslateSellInfoRepository.findAll();
		Collections.reverse(secondTranslateSellInfoList);

		return  new ResponseData(ExceptionMsg.SUCCESS, secondTranslateSellInfoList);
	}

	@ApiOperation(value = "查询指定id的信息")
	@ApiImplicitParam(paramType = "query", name = "id", value = "此条信息的id", required = true)
	@RequestMapping(value = "/getMsgById", method = RequestMethod.GET)
	public ResponseData getMsgById(Long id) {

		if(null == id) {
			return new ResponseData(ExceptionMsg.FAILED_ID_IS_NULL);
		}

		SecondTranslateSellInfo secondTranslateSellInfo = secondTranslateSellInfoRepository.findById(id.longValue());

		if(null == secondTranslateSellInfo) {
			return new ResponseData(ExceptionMsg.USER_NOTEXIST);
		}

		return  new ResponseData(ExceptionMsg.SUCCESS, secondTranslateSellInfo);
	}

}
