package xyz.lsmg.secondtranslate.domain;

import com.alibaba.fastjson.JSON;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @ClassName SecondTranslateSellInfo
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 20:21
 * @Version 1.0
 **/

@ApiModel(description = "data部分")
@Entity(name = "SecondTranslateSellInfo")
public class SecondTranslateSellInfo implements Serializable {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@ApiModelProperty(hidden = true)
	private long id;

	@ApiModelProperty(hidden = true)
	@Column(name = "publishtime")
	private Date publishtime;



	@Column(name = "publisherid")
	private String publisherId;

	/** 标题*/
	private String title;
	/** 详细描述*/
	@Column(name = "objectdescribe")
	private String describe;

	@ApiModelProperty(hidden = true)
	@Transient
	private List<String> images = new ArrayList<>();

	@ApiModelProperty(hidden = true)
	@Column(name = "imagestring")
	private String imageString;

	@ApiModelProperty(hidden = true)
	@Transient
	private String[] imagelist;

	@Column(name = "price")
	private String price;

	@ApiModelProperty(value = "1图书音像，2办公文体，3生活用品，4电子数码，5其它")
	@Column(name = "objectType")

	private String objectType;
	@Column(name = "contactqq")
	private String contactQQ;
	@Column(name = "contactwechat")
	private String contactWechat;

	public void addImagesToList(String imageUrl) {
		images.add(imageUrl);
		imageString = JSON.toJSONString(images);
	}

	public SecondTranslateSellInfo() {

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		publishtime = calendar.getTime();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String[] getImagelist() {
		if(null == imageString) {
			return null;
		}
		imageString = imageString.replaceAll("\"","");
		System.out.println(imageString);
		imagelist = imageString.substring(1, imageString.length()-1).split(",");
		return imagelist;
	}



	public String getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(String publisherId) {
		this.publisherId = publisherId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescribe() {
		return describe;
	}

	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getContactQQ() {
		return contactQQ;
	}

	public void setContactQQ(String contactQQ) {
		this.contactQQ = contactQQ;
	}

	public String getContactWechat() {
		return contactWechat;
	}

	public void setContactWechat(String contactWechat) {
		this.contactWechat = contactWechat;
	}

	@Override
	public String toString() {
		return "{" +
				"id=" + id +
				", publisherId='" + publisherId + '\'' +
				", title='" + title + '\'' +
				", describe='" + describe + '\'' +
				", imagelist='" + imagelist + '\'' +
				", price='" + price + '\'' +
				", objectType='" + objectType + '\'' +
				", contactQQ='" + contactQQ + '\'' +
				", contactWechat='" + contactWechat + '\'' +
				'}';
	}
}
