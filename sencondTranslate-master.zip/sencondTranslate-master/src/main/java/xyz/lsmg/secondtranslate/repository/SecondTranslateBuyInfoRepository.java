package xyz.lsmg.secondtranslate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xyz.lsmg.secondtranslate.domain.SecondTranslateBuyInfo;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;

import java.util.Date;
import java.util.List;

/**
 * @ClassName SecondTranslateSellInfoRepository
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 23:11
 * @Version 1.0
 **/
public interface SecondTranslateBuyInfoRepository extends JpaRepository<SecondTranslateBuyInfo, Long> {

	SecondTranslateBuyInfo findById(long id);

	List<SecondTranslateBuyInfo> findByPublisherIdBefore(Date date);

	List<SecondTranslateBuyInfo> findByPublishtimeBefore(Date date);

	List<SecondTranslateBuyInfo> findAllByPublisherId(String username);
}
