package xyz.lsmg.secondtranslate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xyz.lsmg.secondtranslate.domain.ApiUser;

/**
 * @ClassName ApiUserRepository
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/23 10:49
 * @Version 1.0
 **/
public interface ApiUserRepository extends JpaRepository<ApiUser, Long> {

	ApiUser findByUsername(String username);
}
