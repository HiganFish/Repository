package xyz.lsmg.secondtranslate.domain.result;

/**
 * @ClassName ExceptionMsg
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/20 20:00
 * @Version 1.0
 **/
public enum ExceptionMsg {

	/** 成功操作*/
	SUCCESS(0, "操作成功"),
	/** 用户不存在*/
	USER_NOTEXIST(-1, "Id无效, 无此用户"),
	/** 上传失败*/
	UPLOAD_FAILED(-1, "上传图片失败"),
	/** 删除失败*/
	DEL_FAILED(-1, "删除信息失败， 信息不匹配"),
	/** 删除失败*/
	FAILED_ID_IS_NULL(-1, "id不可以为空"),
	/** 查询失败*/
	FAILED_GET_USERINFO(-1, "username不可以为空");

	private ExceptionMsg(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}
	private int code;
	private String msg;

	public int getCode() {
		return code;
	}
	public String getMsg() {
		return msg;
	}
}
