package xyz.lsmg.secondtranslate.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xyz.lsmg.secondtranslate.common.Const;
import xyz.lsmg.secondtranslate.domain.SecondTranslateBuyInfo;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;

import java.io.File;


/**
 * @ClassName ImageUtil
 * @Description 负责图片路径和图片压缩
 * @Author lsmg
 * Date 2019/7/20 22:12
 * @Version 1.0
 **/
public class ImageUtil {

	private static Logger logger = LoggerFactory.getLogger(ImageUtil.class);

	public static boolean delImgesByInfo(SecondTranslateSellInfo secondTranslateSellInfo) {

		if(null == secondTranslateSellInfo.getImagelist()){
			return false;
		}

		String[] imgArray = secondTranslateSellInfo.getImagelist();

		for(String imgUrl : imgArray) {
			String url = imgUrl.trim().replace("https://translate.lsmg.xyz/imgs/", Const.UPLOAD_IMAGE_PATH + File.separator);
			File file = new File(url);

			if(file.exists()){
				file.delete();
				logger.info("删除售卖文件: "+url+"成功");
			}else{
				logger.info("售卖文件: "+url+"不存在");
			}

		}

		return true;
	}

}
