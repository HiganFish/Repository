package xyz.lsmg.secondtranslate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import xyz.lsmg.secondtranslate.domain.SecondTranslateSellInfo;
import xyz.lsmg.secondtranslate.repository.SecondTranslateSellInfoRepository;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @ClassName AutoDelMsgTests
 * @Description TODO
 * @Author lsmg
 * Date 2019/7/21 16:52
 * @Version 1.0
 **/

@RunWith(SpringRunner.class)
@SpringBootTest
public class AutoDelMsgTests {


	@Autowired
	SecondTranslateSellInfoRepository secondTranslateSellInfoRepository;


	@Test
	public void delMsg() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.DAY_OF_MONTH, -60);

		List<SecondTranslateSellInfo> secondTranslateSellInfoList = secondTranslateSellInfoRepository.findByPublishtimeBefore(calendar.getTime());

		for(SecondTranslateSellInfo secondTranslateSellInfo : secondTranslateSellInfoList) {
			System.out.println(secondTranslateSellInfo.toString());
		}
	}
}
