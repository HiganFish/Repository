var i=1;   //保存账号数量
var theUser=[];
var thePassword=[];
var click_bool=0;       //判断输入栏是否被点击  防止使用默认内容
var int=self.setInterval("change()",1000);  //计时器控制钟表
var hour=0.008,min=0.1,sec=6;       //初始角度  同时为以后根据系统时间更改 做准备
var screen_x=window.screen.width;
var screen_y=window.screen.height;

theUser[0]="lsmg";  //“管理”的账号密码  =_=!
thePassword[0]="d@123";
function login() {
    const user = document.getElementById("zh").value;  //账号
    const password = document.getElementById("mm").value;//密码
    var j=0;
    var bool=0;
    for(;j<=i-1;j++){
        if(user===theUser[j]){ //判断账号
            if(password===thePassword[j]){      //判断密码
                if(j===0){  //判断管理员= ，=
                    reminder("管理登陆啦");
                }else{
                    reminder("登陆成功啦");
                }
                bool=1;
                window.location.href='http://self.lsmg.xyz'+"?valus="+encodeURI(user); //解决中文乱码
            }else{
                reminder("你的密码好像不对哦");
                bool=1;
            }
        }
    }
    if(bool===0){
        reminder("你输入的账号不存在哦");

    }
}
function reg() {
    const user = document.getElementById("zh");
    const password = document.getElementById("mm");
    const login = document.getElementById("login");
    if(login.innerText==="注册"){                 //更改显示内容
        user.className="input_style_reg";
        password.className="input_style_reg";
        user.value="输入你的新账号(咱家支持汉字哦)";
        password.value="在这里输入你的密码啦";
        login.innerText="输入完成后点击我啦";
    }else{
        if(user.value !==""&&password.value!==""&&click_bool===1){      //判断注册
            if(boolUserExist(user.value)===false){
                reminder("账号存在换一个吧");
                return 0;
            }
        theUser[i]=user.value;
        thePassword[i]=password.value;
        i++;
        user.className="input_style";
        password.className="input_style";
        reminder("你的账号: "+user.value+"注册成功");
        login.innerText="注册";       //注册完后清空内容
        user.value="";
        password.value="";
        }else{
            reminder("你账号和密码不能为空哦");
        }
    }
}

function noValue(object) {  //清空输入栏
    if(object.className==="input_style_reg")
    object.value="";
    click_bool=1;
}

function boolUserExist(a) {   //判断用户是否存在
    for(var j=0;j<=i-1;j++){
        if(a===theUser[j]){
            return false;
        }
    }
    return true;
}
function change(){  //控制钟表指针走动
    var a=document.getElementById("hour")
    a.style.transform= "rotate(" + hour + "deg)";
    hour+=0.008;
    var b=document.getElementById("min")
    b.style.transform= "rotate(" + min + "deg)";
    min+=0.1;
    var c=document.getElementById("sec")
    c.style.transform= "rotate(" + sec + "deg)";
    sec+=6;
}
function havaSystemTime() {  //获取当前系统时间转换为角度
    var time=new Date();
    hour=time.getHours()*30;
    min=time.getMinutes()*6;
    sec=time.getSeconds()*6-180;
}
function reminder(value){   //使用这个提示信息防止js被阻塞导致时钟停止
    var re=document.getElementById("remindText");
    re.innerText=value;
    setTimeout(deleteReminder,1000);
}
function deleteReminder(){  //一秒延迟后还原提示信息
    var re=document.getElementById("remindText");
    re.innerText="(゜-゜)つロ干杯~-bilibili";
}
window.onload=function () {  //页面加载后获取系统时间
    havaSystemTime();
}
