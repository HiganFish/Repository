let all_count = 1,time=1;  //allcount用于更改全家照 time用于触发全家照点击次数
var i1=1,i2=1,i3=1,i4=1; //记录四个更改图片的名字
var int=self.setInterval("miku_change()",2000);  //定时更改muku的图片
var int=self.setInterval("RinLen_change()",1800); //定时更改图片
var int=self.setInterval("Luka_change()",2200);//定时更改图片
var int=self.setInterval("LTY_change()",2000);//定时更改图片

var result=0;

function img_all_click(object) { //更改全家图片和触发“彩蛋？”
    time++;
    if(time===8){
        alert("恭喜你收获v家合唱一枚");
        window.open("https://www.bilibili.com/video/av14065851/", "_blank");

    }
    switch (all_count) {  //根据点击更改图片
        case 1:object.src='image/all_1.jpg';
        all_count++;
        break;
        case 2:object.src='image/all_2.jpg';
            all_count++;
            break;
        case 3:object.src='image/all_3.jpg';
            all_count++;
            break;
        case 4:object.src='image/all.jpg';
            all_count=1;
            break;
    }
}

function miku_change() {  //以下四个为更改图片
    document.getElementById("img_miku").src="image/miku/miku_"+i1+".jpg";
    i1=(i1===4)?1:i1+1;
}
function RinLen_change() {
    document.getElementById("img_RinLen").src="image/RinLen/RinLen_"+i2+".jpg";
    i2=(i2===4)?1:i2+1;
}
function Luka_change() {
    document.getElementById("img_Luka").src="image/Luka/Luka_"+i3+".jpg";
    i3=(i3===4)?1:i3+1;
}
function LTY_change() {
    document.getElementById("img_LTY").src="image/LTY/LTY_"+i4+".jpg";
    i4=(i4===4)?1:i4+1;
}

function logout(){  //登出
    window.location.href="http://www.lsmg.xyz"

}

window.onload=function () {

    var url=window.location.search;  //获取url的名字
    if(url.indexOf("?")!==-1){
        result = url.substr(url.indexOf("=")+1); //保存用户名
        var object=document.getElementById("user");
        if(result===encodeURI("lsmg")){ //判断用户身份 并显示
            object.innerText="欢迎管理员回来"
        }else{
        object.innerText="欢迎 ："+decodeURI(result) +" 回来";
        }
    }
    if(result===0){  //防止没有登陆就进入这个页面。。。不过不安全简单的这样实现了下
        document.write("请先登录");
    }
}